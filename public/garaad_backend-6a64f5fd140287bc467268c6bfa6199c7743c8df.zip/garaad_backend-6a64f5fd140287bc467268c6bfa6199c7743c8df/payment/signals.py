"""
Signal handlers for the payment app.
Automatically create referral rewards when orders are completed.
"""
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Order
from accounts.models import ReferralReward
from decimal import Decimal


@receiver(post_save, sender=Order)
def create_referral_reward(sender, instance, created, **kwargs):
    """
    Create a referral reward when an order is completed.
    Awards the referrer 20% of the subscription amount.
    """
    # Only process completed orders
    if instance.status != 'completed':
        return
    
    # Check if user was referred by someone
    if not instance.user.referred_by:
        return
    
    # Check if reward already exists for this order (prevent duplicates)
    if ReferralReward.objects.filter(order=instance).exists():
        return
    
    # Only reward for subscription orders
    subscription_items = instance.items.filter(item_type='subscription')
    if not subscription_items.exists():
        return
    
    # Calculate reward (20% of total order amount)
    commission_percentage = Decimal('20.00')
    reward_amount = ReferralReward.calculate_reward(
        instance.total_amount, 
        commission_percentage
    )
    
    # Create the referral reward
    referral_reward = ReferralReward.objects.create(
        referrer=instance.user.referred_by,
        referred_user=instance.user,
        order=instance,
        reward_amount=reward_amount,
        currency=instance.currency,
        commission_percentage=commission_percentage,
        status='pending',
        notes=f'Reward for {instance.user.username} subscription via {instance.order_number}'
    )
    
    # Award bonus referral points to the referrer (in addition to monetary reward)
    instance.user.referred_by.award_referral_points(50)  # 50 points for subscription
    
    print(f"✅ Referral reward created: {referral_reward}")
