import os
import django
import json
from django.core.serializers.json import DjangoJSONEncoder

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'garaad.settings')
django.setup()

from api.admin_dashboard import AdminDashboardService

try:
    print("Fetching dashboard data...")
    data = AdminDashboardService.get_dashboard_data()
    print("Serializing to JSON...")
    json_data = json.dumps(data, cls=DjangoJSONEncoder)
    print("Serialization successful!")
    print(f"JSON length: {len(json_data)}")
except Exception as e:
    print(f"FAILED: {e}")
    import traceback
    traceback.print_exc()
