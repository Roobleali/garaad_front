from rest_framework import serializers
from accounts.models import User, UserOnboarding
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from django.db import models, transaction
import logging
from .models import Notification
from django.utils import timezone

logger = logging.getLogger(__name__)


class UserOnboardingSerializer(serializers.ModelSerializer):
    preferred_study_time = serializers.ChoiceField(choices=[
        ('morning', 'Aroorti Subaxda inta aan quraacaynayo'),
        ('afternoon', 'Waqtiga Nasashasha intaan Khadaynayo'),
        ('evening', 'Habeenki ah ka dib cashada ama Kahor intan seexanin'),
        ('flexible', 'Waqti kale oo maalintayda ah')
    ], default='flexible')

    class Meta:
        model = UserOnboarding
        fields = ['goal', 'learning_approach',
                  'topic', 'math_level', 'preferred_study_time']


class SignupWithOnboardingSerializer(serializers.Serializer):
    # User credentials
    name = serializers.CharField(required=True)
    email = serializers.EmailField(required=True)
    password = serializers.CharField(
        required=True, style={'input_type': 'password'}, write_only=True)

    # Onboarding fields
    goal = serializers.CharField(
        required=False, default="Horumarinta xirfadaha")
    learning_approach = serializers.CharField(
        required=False, default="Waxbarasho shaqsiyeed")
    topic = serializers.CharField(required=False, default="Xisaab")
    math_level = serializers.CharField(required=False, default="Bilowga")
    preferred_study_time = serializers.ChoiceField(choices=[
        ('morning', 'Aroorti Subaxda inta aan quraacaynayo'),
        ('afternoon', 'Waqtiga Nasashasha intaan Khadaynayo'),
        ('evening', 'Habeenki ah ka dib cashada ama Kahor intan seexanin'),
        ('flexible', 'Waqti kale oo maalintayda ah')
    ], default='flexible', required=False)
    referral_code = serializers.CharField(max_length=20, required=False, allow_blank=True)
    promo_code = serializers.CharField(max_length=20, required=False, allow_blank=True)
    onboarding_data = serializers.DictField(required=False, write_only=True)

    def validate_name(self, value):
        """
        Validate that name is not empty and doesn't contain invalid characters
        """
        if not value or not value.strip():
            raise serializers.ValidationError("Name cannot be empty")
        if len(value) > 150:  # Django's default max_length for username
            raise serializers.ValidationError("Name is too long")
        return value.strip()

    def validate_email(self, value):
        """
        Check if the email already exists
        """
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError(
                "User with this email already exists.")
        return value.lower()  # Normalize email to lowercase

    def validate_password(self, value):
        """
        Validate password strength
        """
        if len(value) < 8:
            raise serializers.ValidationError(
                "Password must be at least 8 characters long")
        return value


    @transaction.atomic
    def create(self, validated_data):
        """
        Create user and onboarding profile in a transaction
        """
        try:
            # Extract user data
            name = validated_data.pop('name')
            email = validated_data.pop('email')
            password = validated_data.pop('password')
            referral_code = validated_data.pop('referral_code', None)
            promo_code = validated_data.pop('promo_code', None)

            # Create a sanitized username (required by Django)
            # Use email as username to ensure uniqueness if name is not suitable
            username = name

            # If name contains spaces, use the email prefix as username
            if ' ' in name or len(name) > 150:
                username = email.split('@')[0]

            # Check for username conflicts and append number if needed
            base_username = username
            counter = 1
            while User.objects.filter(username=username).exists():
                username = f"{base_username}{counter}"
                counter += 1

            # Get first and last name safely
            name_parts = name.split(' ', 1)
            first_name = name_parts[0] if name_parts else name
            last_name = name_parts[1] if len(name_parts) > 1 else ''

            # Create user
            user = User.objects.create_user(
                username=username[:150],  # Ensure within field limit
                email=email,
                password=password,
                first_name=first_name[:30],  # Respect Django field limits
                last_name=last_name[:150]
            )

            # --- PREMIUN PROMO LOGIC ---
            # Check for special premium promo code
            if promo_code == "Garaad#2026" or referral_code == "Garaad#2026":
                user.is_premium = True
                user.subscription_type = 'lifetime'
                user.save()
            
            # --- REFERRAL LOGIC ---
            # If a regular referral code was provided (and it's not the special promo code)
            elif referral_code:
                try:
                    referrer = User.objects.get(referral_code=referral_code)
                    user.referred_by = referrer
                    user.save()
                    
                    # Store referral count and award points
                    referrer.award_referral_points(10) # 10 points for a new referral
                except User.DoesNotExist:
                    pass # Ignore invalid referral codes for now

            # --- ONBOARDING DATA EXTRACTION ---
            # Support both top-level fields and nested onboarding_data
            onboarding_input = validated_data.pop('onboarding_data', {})
            
            goal = onboarding_input.get('goal') or validated_data.get('goal', "Horumarinta xirfadaha")
            learning_approach = onboarding_input.get('learning_approach') or validated_data.get('learning_approach', "Waxbarasho shaqsiyeed")
            topic = onboarding_input.get('topic') or validated_data.get('topic', "Xisaab")
            math_level = onboarding_input.get('math_level') or validated_data.get('math_level', "Bilowga")
            preferred_study_time = onboarding_input.get('preferred_study_time') or validated_data.get('preferred_study_time', 'flexible')

            # Create onboarding profile
            onboarding = UserOnboarding.objects.create(
                user=user,
                goal=goal,
                learning_approach=learning_approach,
                topic=topic,
                math_level=math_level,
                preferred_study_time=preferred_study_time,
                has_completed_onboarding=True
            )

            return {
                'user': user,
                'onboarding': onboarding,
            }
        except Exception as e:
            # Log any errors during user creation
            logger.error(f"Error creating user: {str(e)}")
            raise serializers.ValidationError(
                f"Waan ka xunnahay, is-diiwaangelintu kuma guuleysan: {str(e)}")


class SigninSerializer(serializers.Serializer):
    email = serializers.EmailField(required=True)
    password = serializers.CharField(
        required=True, style={'input_type': 'password'}, write_only=True)

    def validate(self, data):
        email = data.get('email')
        password = data.get('password')

        if email and password:
            user = authenticate(request=self.context.get(
                'request'), username=email, password=password)

            if not user:
                raise serializers.ValidationError(
                    "Macluumaadka aad gelisay ma saxno. Fadlan dib isku day.")

            if not user.is_active:
                raise serializers.ValidationError("Akoonkan ma shaqeynayo.")

            data['user'] = user
            return data

        raise serializers.ValidationError("Fadlan geli email-kaaga iyo sirtaada (password).")


class UserSerializer(serializers.ModelSerializer):
    has_completed_onboarding = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name',
                  'last_name', 'is_premium', 'has_completed_onboarding', 'is_superuser', 'is_email_verified']

    def get_has_completed_onboarding(self, obj):
        try:
            return obj.useronboarding.has_completed_onboarding
        except UserOnboarding.DoesNotExist:
            return False


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['id', 'type', 'title', 'message', 'data', 'is_read', 'created_at']
        read_only_fields = ['id', 'type', 'title', 'message', 'data', 'created_at']


class PublicSocialProofSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'date_joined']
