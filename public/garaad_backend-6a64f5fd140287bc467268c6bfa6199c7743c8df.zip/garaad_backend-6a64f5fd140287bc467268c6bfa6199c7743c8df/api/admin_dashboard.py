from django.db.models import Count, Q, Sum, Avg, F, Max, Case, When
from django.utils import timezone
from django.contrib.auth import get_user_model
from datetime import timedelta, date
from courses.models import (
    Course, Lesson, Problem, UserProgress, CourseEnrollment
)
from api.models import Notification
from accounts.models import UserProfile, StudentProfile
import logging
import traceback

User = get_user_model()
logger = logging.getLogger(__name__)

class AdminDashboardService:
    """
    Comprehensive admin dashboard service for LMS platform
    """
    
    @staticmethod
    def get_dashboard_data():
        """
        Get complete dashboard data with all important metrics
        """
        dashboard_data = {}
        errors = []
        
        methods = [
            ('overview', AdminDashboardService.get_overview_stats),
            ('users', AdminDashboardService.get_user_stats),
            ('courses', AdminDashboardService.get_course_stats),
            ('learning', AdminDashboardService.get_learning_stats),
            ('engagement', AdminDashboardService.get_engagement_stats),
            ('revenue', AdminDashboardService.get_revenue_stats),
            ('system', AdminDashboardService.get_system_stats),
            ('recent_activity', AdminDashboardService.get_recent_activity),
            ('top_performers', AdminDashboardService.get_top_performers),
            ('alerts', AdminDashboardService.get_system_alerts)
        ]
        
        for key, method in methods:
            try:
                dashboard_data[key] = method()
            except Exception as e:
                logger.error(f"Error in dashboard method {key}: {str(e)}")
                logger.error(traceback.format_exc())
                dashboard_data[key] = None
                errors.append(f"{key}: {str(e)}")
        
        if errors:
            dashboard_data['_errors'] = errors
            
        return dashboard_data
    
    @staticmethod
    def get_overview_stats():
        """
        Get high-level overview statistics
        """
        week_ago = timezone.now() - timedelta(days=7)
        
        total_users = User.objects.count()
        total_courses = Course.objects.count()
        total_lessons = Lesson.objects.count()
        total_problems = Problem.objects.count()
        
        # Active users (users who have logged in last 7 days)
        active_users = User.objects.filter(
            last_login__gte=week_ago
        ).count()
        
        # New users this week
        new_users_week = User.objects.filter(
            date_joined__gte=week_ago
        ).count()
        
        # Completion rate
        total_enrollments = CourseEnrollment.objects.count()
        completed_courses = CourseEnrollment.objects.filter(
            progress_percent=100
        ).count()
        completion_rate = (completed_courses / total_enrollments * 100) if total_enrollments > 0 else 0
        
        return {
            'total_users': total_users,
            'total_courses': total_courses,
            'total_lessons': total_lessons,
            'total_problems': total_problems,
            'active_users': active_users,
            'new_users_week': new_users_week,
            'completion_rate': round(completion_rate, 2),
            'total_enrollments': total_enrollments
        }
    
    @staticmethod
    def get_user_stats():
        """
        Get detailed user statistics
        """
        today = timezone.now().date()
        week_ago = timezone.now() - timedelta(days=7)
        month_ago = timezone.now() - timedelta(days=30)
        
        # Basic user counts
        total_users = User.objects.count()
        premium_users = User.objects.filter(is_premium=True).count()
        free_users = total_users - premium_users
        
        # Subscription breakdown
        monthly_subs = User.objects.filter(
            is_premium=True, 
            subscription_type='monthly'
        ).count()
        yearly_subs = User.objects.filter(
            is_premium=True, 
            subscription_type='yearly'
        ).count()
        lifetime_subs = User.objects.filter(
            is_premium=True, 
            subscription_type='lifetime'
        ).count()
        
        # New registrations
        new_today = User.objects.filter(date_joined__date=today).count()
        new_week = User.objects.filter(date_joined__gte=week_ago).count()
        new_month = User.objects.filter(date_joined__gte=month_ago).count()
        
        # Recently active users (last 24 hours)
        recent_active = User.objects.filter(
            last_login__gte=timezone.now() - timedelta(hours=24)
        ).values('id', 'username', 'email', 'last_login', 'is_premium').order_by('-last_login')[:10]
        
        return {
            'total_users': total_users,
            'premium_users': premium_users,
            'free_users': free_users,
            'subscription_breakdown': {
                'monthly': monthly_subs,
                'yearly': yearly_subs,
                'lifetime': lifetime_subs
            },
            'new_registrations': {
                'today': new_today,
                'week': new_week,
                'month': new_month
            },
            'recent_active_users': list(recent_active)
        }
    
    @staticmethod
    def get_course_stats():
        """
        Get course and content statistics
        """
        # Basic course stats
        total_courses = Course.objects.count()
        published_courses = Course.objects.filter(is_published=True).count() if hasattr(Course, 'is_published') else total_courses
        total_lessons = Lesson.objects.count()
        total_problems = Problem.objects.count()
        
        # Course enrollments
        total_enrollments = CourseEnrollment.objects.count()
        unique_enrolled_users = CourseEnrollment.objects.values('user').distinct().count()
        
        # Popular courses (most enrolled)
        popular_courses = Course.objects.annotate(
            enrollment_count=Count('enrollments')
        ).order_by('-enrollment_count')[:5].values(
            'id', 'title', 'enrollment_count'
        )
        
        # Course completion stats
        completed_courses = CourseEnrollment.objects.filter(progress_percent=100).count()
        in_progress_courses = CourseEnrollment.objects.filter(
            progress_percent__gt=0, progress_percent__lt=100
        ).count()
        not_started_courses = CourseEnrollment.objects.filter(progress_percent=0).count()
        
        # Average progress
        avg_progress = CourseEnrollment.objects.aggregate(
            avg_progress=Avg('progress_percent')
        )['avg_progress'] or 0
        
        # Content engagement
        total_lessons_completed = UserProgress.objects.filter(status='completed').count()
        total_problems_solved = UserProgress.objects.aggregate(
            total_problems=Sum('problems_solved')
        )['total_problems'] or 0
        
        return {
            'total_courses': total_courses,
            'published_courses': published_courses,
            'total_lessons': total_lessons,
            'total_problems': total_problems,
            'enrollments': {
                'total': total_enrollments,
                'unique_users': unique_enrolled_users,
                'completed': completed_courses,
                'in_progress': in_progress_courses,
                'not_started': not_started_courses
            },
            'avg_progress': round(avg_progress, 2),
            'popular_courses': list(popular_courses),
            'content_engagement': {
                'lessons_completed': total_lessons_completed,
                'problems_solved': total_problems_solved
            }
        }
    
    @staticmethod
    def get_learning_stats():
        """
        Get learning and progress statistics
        """
        # Problem difficulty breakdown
        problem_types = Problem.objects.values('question_type').annotate(
            count=Count('id')
        ).order_by('question_type')
        
        return {
            'problem_types': list(problem_types),
        }
    
    @staticmethod
    def get_engagement_stats():
        """
        Get user engagement and retention statistics
        """
        # Notification engagement
        total_notifications = Notification.objects.count()
        read_notifications = Notification.objects.filter(is_read=True).count()
        notification_engagement = read_notifications / total_notifications * 100 if total_notifications > 0 else 0
        
        return {
            'notification_engagement': round(notification_engagement, 2),
        }
    
    @staticmethod
    def get_revenue_stats():
        """
        Get subscription and revenue statistics
        """
        today = timezone.now().date()
        month_ago = today - timedelta(days=30)
        
        # Premium user breakdown
        premium_users = User.objects.filter(is_premium=True)
        
        # Subscription types
        monthly_count = premium_users.filter(subscription_type='monthly').count()
        yearly_count = premium_users.filter(subscription_type='yearly').count()
        lifetime_count = premium_users.filter(subscription_type='lifetime').count()
        
        # New premium subscriptions this month
        new_premium_month = premium_users.filter(
            subscription_start_date__gte=month_ago
        ).count() if hasattr(User, 'subscription_start_date') else 0
        
        # Active subscriptions (not expired)
        active_subscriptions = premium_users.filter(
            Q(subscription_type='lifetime') |
            Q(subscription_end_date__gte=today)
        ).count() if hasattr(User, 'subscription_end_date') else premium_users.count()
        
        # Estimate monthly recurring revenue (MRR)
        # Assuming monthly = $10, yearly = $100, lifetime = $500
        estimated_mrr = (monthly_count * 10) + (yearly_count * 100 / 12)
        estimated_arr = estimated_mrr * 12
        
        # Conversion rate
        total_users = User.objects.count()
        conversion_rate = premium_users.count() / total_users * 100 if total_users > 0 else 0
        
        expired_count = 0
        if hasattr(User, 'subscription_end_date'):
            expired_count = premium_users.filter(
                subscription_end_date__lt=today,
                subscription_type__in=['monthly', 'yearly']
            ).count()

        return {
            'subscription_breakdown': {
                'monthly': monthly_count,
                'yearly': yearly_count,
                'lifetime': lifetime_count,
                'total_premium': premium_users.count()
            },
            'new_premium_month': new_premium_month,
            'active_subscriptions': active_subscriptions,
            'estimated_revenue': {
                'mrr': round(estimated_mrr, 2),
                'arr': round(estimated_arr, 2)
            },
            'conversion_rate': round(conversion_rate, 2),
            'churn_indicators': {
                'expired_subscriptions': expired_count
            }
        }
    
    @staticmethod
    def get_system_stats():
        """
        Get system and technical statistics
        """
        # Database counts
        db_stats = {
            'users': User.objects.count(),
            'courses': Course.objects.count(),
            'lessons': Lesson.objects.count(),
            'problems': Problem.objects.count(),
            'enrollments': CourseEnrollment.objects.count(),
            'user_progress': UserProgress.objects.count(),
            'notifications': Notification.objects.count(),
        }
        
        # Recent system activity
        week_ago = timezone.now() - timedelta(days=7)
        
        recent_activity = {
            'new_users_week': User.objects.filter(date_joined__gte=week_ago).count(),
            'lessons_completed_week': UserProgress.objects.filter(
                completed_at__gte=week_ago
            ).count(),
            'notifications_sent_week': Notification.objects.filter(
                created_at__gte=week_ago
            ).count()
        }
        
        return {
            'database_stats': db_stats,
            'recent_activity': recent_activity,
            'last_updated': timezone.now().isoformat()
        }
    
    @staticmethod
    def get_recent_activity():
        """
        Get recent user activities and system events
        """
        # Recent user registrations
        recent_users = User.objects.order_by('-date_joined')[:10].values(
            'id', 'username', 'email', 'date_joined', 'is_premium'
        )
        
        # Recent course completions
        recent_completions = CourseEnrollment.objects.filter(
            progress_percent=100
        ).order_by('-enrolled_at')[:10].values(
            'user__username', 'course__title', 'progress_percent', 'enrolled_at'
        )
        
        return {
            'recent_users': list(recent_users),
            'recent_completions': list(recent_completions),
        }
    
    @staticmethod
    def get_top_performers():
        """
        Get top performing users and courses
        """
        popular_courses = Course.objects.annotate(
            enrollment_count=Count('enrollments')
        ).order_by('-enrollment_count')[:5].values(
            'id', 'title', 'enrollment_count'
        )
        
        # Use Case/When for broader compatibility across DB engines
        popular_lessons = Lesson.objects.annotate(
            completion_count=Count(
                Case(When(user_progress__status='completed', then=1))
            )
        ).order_by('-completion_count')[:5].values(
            'id', 'title', 'completion_count', 'course__title'
        )
        
        return {
            'popular_courses': list(popular_courses),
            'popular_lessons': list(popular_lessons)
        }
    
    @staticmethod
    def get_system_alerts():
        """
        Get system alerts and warnings
        """
        alerts = []
        today = timezone.now().date()
        
        # Check for users with expired subscriptions
        if hasattr(User, 'subscription_end_date'):
            expired_subs = User.objects.filter(
                is_premium=True,
                subscription_end_date__lt=today,
                subscription_type__in=['monthly', 'yearly']
            ).count()
            
            if expired_subs > 0:
                alerts.append({
                    'type': 'warning',
                    'title': 'Expired Subscriptions',
                    'message': f'{expired_subs} users have expired premium subscriptions',
                    'count': expired_subs
                })
        
        return alerts