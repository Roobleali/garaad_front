from rest_framework.decorators import api_view, permission_classes
from django.utils import timezone
from django.db import transaction
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
import logging
import traceback
from .serializers import (
    SignupWithOnboardingSerializer,
    SigninSerializer,
    UserSerializer,
    NotificationSerializer,
    PublicSocialProofSerializer
)
from .models import Notification
from rest_framework import viewsets
from rest_framework.decorators import action
from django.db.models import F
from datetime import timedelta
from .admin_dashboard import AdminDashboardService
from django.contrib.admin.views.decorators import staff_member_required
from django.utils.decorators import method_decorator
from django.db.models import Max, Sum, Count
from django.contrib.auth import get_user_model

User = get_user_model()

# Configure logger
logger = logging.getLogger(__name__)


@api_view(['GET'])
def api_root(request):
    """
    API root view that provides information about available endpoints.
    """
    return Response({
        'status': 'online',
        'version': '1.0.0',
        'endpoints': {
            'auth': {
                'signup': '/api/auth/signup/',
                'signin': '/api/auth/signin/',
                'refresh': '/api/auth/refresh/',
                'profile': '/api/auth/profile/',
                'student/register': '/api/auth/student/register/'
            },
            'hello': '/hello-world/',
            'lms': '/api/lms/',
        }
    }, status=status.HTTP_200_OK)


class SignupView(APIView):
    """
    API view for signing up with onboarding information in a single request.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        try:
            data = request.data
            email = data.get('email')
            password = data.get('password')
            promo_code = data.get('promo_code')
            referral_code = data.get('referral_code')

            # --- Early Upgrade Logic for Existing Users ---
            if email and (promo_code == "Garaad#2026" or referral_code == "Garaad#2026"):
                try:
                    user = User.objects.get(email=email)
                    from django.contrib.auth import authenticate
                    authenticated_user = authenticate(email=email, password=password)
                    if authenticated_user:
                        with transaction.atomic():
                            user.is_premium = True
                            user.subscription_type = 'lifetime'
                            user.save()
                            
                            # Also handle onboarding if provided
                            onboarding_input = data.get('onboarding_data', {})
                            if onboarding_input or data.get('goal'): # Check for any onboarding data
                                try:
                                    from accounts.models import UserOnboarding
                                    # Support both nested and top-level fields
                                    goal = onboarding_input.get('goal') or data.get('goal', "Horumarinta xirfadaha")
                                    learning_approach = onboarding_input.get('learning_approach') or data.get('learning_approach', "Waxbarasho shaqsiyeed")
                                    topic = onboarding_input.get('topic') or data.get('topic', "Xisaab")
                                    math_level = onboarding_input.get('math_level') or data.get('math_level', "Bilowga")
                                    preferred_study_time = onboarding_input.get('preferred_study_time') or data.get('preferred_study_time', 'flexible')

                                    UserOnboarding.objects.update_or_create(
                                        user=user,
                                        defaults={
                                            'goal': goal,
                                            'learning_approach': learning_approach,
                                            'topic': topic,
                                            'math_level': math_level,
                                            'preferred_study_time': preferred_study_time,
                                            'has_completed_onboarding': True
                                        }
                                    )
                                except Exception as onboard_err:
                                    logger.error(f"Error updating onboarding for existing user: {onboard_err}")
                        
                        refresh = RefreshToken.for_user(user)
                        from accounts.serializers import UserOnboardingSerializer
                        try:
                            from accounts.models import UserOnboarding
                            onboarding = UserOnboarding.objects.get(user=user)
                            onboarding_output = UserOnboardingSerializer(onboarding).data
                        except:
                            onboarding_output = None

                        return Response({
                            'message': 'Akoonkaaga waa la aqoonsaday, waxaana lagu daray Premium! Ku soo dhowaw Garaad.',
                            'user': UserSerializer(user).data,
                            'onboarding': onboarding_output,
                            'tokens': {
                                'access': str(refresh.access_token),
                                'refresh': str(refresh)
                            }
                        }, status=status.HTTP_200_OK)
                except User.DoesNotExist:
                    pass

            serializer = SignupWithOnboardingSerializer(data=request.data)

            if serializer.is_valid():
                # Create user and onboarding data (transaction handled in serializer)
                result = serializer.save()

                # Generate JWT tokens for the new user
                user = result['user']
                onboarding = result['onboarding']
                refresh = RefreshToken.for_user(user)

                # Import UserOnboardingSerializer here to avoid circular imports
                from accounts.serializers import UserOnboardingSerializer

                # Return user data, onboarding data, and tokens
                return Response({
                    'message': 'Si guul leh ayaad isu diiwaangelisay. Ku soo dhowaw Garaad!',
                    'user': UserSerializer(user).data,
                    'onboarding': UserOnboardingSerializer(onboarding).data,
                    'tokens': {
                        'refresh': str(refresh),
                        'access': str(refresh.access_token),
                    }
                }, status=status.HTTP_201_CREATED)

            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            # Log the full error with traceback
            logger.error(f"Signup error: {str(e)}")
            logger.error(traceback.format_exc())

            # Return a more informative error response
            return Response({
                'error': 'Cillad ayaa dhacday xilligii is-diiwaangelinta.',
                'detail': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class SigninView(APIView):
    """
    API view for user authentication and token generation.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        try:
            serializer = SigninSerializer(
                data=request.data, context={'request': request})

            if serializer.is_valid():
                user = serializer.validated_data['user']
                refresh = RefreshToken.for_user(user)

                # Import UserOnboardingSerializer here to avoid circular imports
                from accounts.serializers import UserOnboardingSerializer

                # Get user's onboarding data if it exists
                try:
                    from accounts.models import UserOnboarding
                    onboarding = UserOnboarding.objects.get(user=user)
                    onboarding_data = UserOnboardingSerializer(onboarding).data
                except Exception as e:
                    onboarding_data = None

                return Response({
                    'user': UserSerializer(user).data,
                    'onboarding': onboarding_data,
                    'tokens': {
                        'refresh': str(refresh),
                        'access': str(refresh.access_token),
                    }
                }, status=status.HTTP_200_OK)

            return Response(serializer.errors, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            logger.error(f"Signin error: {str(e)}")
            logger.error(traceback.format_exc())
            return Response({
                'error': 'An error occurred during sign-in',
                'detail': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class NotificationViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = NotificationSerializer
    
    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)
    
    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        self.get_queryset().update(is_read=True)
        return Response({'message': 'All notifications marked as read'})
    
    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        notification = self.get_object()
        notification.is_read = True
        notification.save()
        return Response({'message': 'Notification marked as read'})
    
    @action(detail=False, methods=['get'])
    def unread_count(self, request):
        count = self.get_queryset().filter(is_read=False).count()
        return Response({'unread_count': count})


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_dashboard(request):
    """
    Comprehensive admin dashboard with all LMS metrics
    Requires superuser or staff permissions
    """
    # Check if user is admin/staff
    if not (request.user.is_staff or request.user.is_superuser):
        return Response({
            'error': 'Access denied. Admin privileges required.'
        }, status=status.HTTP_403_FORBIDDEN)
    
    try:
        dashboard_data = AdminDashboardService.get_dashboard_data()
        
        # Check if there were any internal errors captured by the service
        internal_errors = dashboard_data.pop('_errors', [])
        
        return Response({
            'success': True,
            'data': dashboard_data,
            'errors': internal_errors,
            'generated_at': timezone.now().isoformat()
        })
    except Exception as e:
        logger.error(f"Critical error in admin dashboard view: {str(e)}")
        logger.error(traceback.format_exc())
        return Response({
            'error': 'Critical failure in dashboard generation',
            'detail': str(e),
            'traceback': traceback.format_exc() if settings.DEBUG else None
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_users_overview(request):
    """
    Detailed user overview for admin dashboard
    """
    if not (request.user.is_staff or request.user.is_superuser):
        return Response({
            'error': 'Access denied. Admin privileges required.'
        }, status=status.HTTP_403_FORBIDDEN)
    
    try:
        user_stats = AdminDashboardService.get_user_stats()
        return Response({
            'success': True,
            'data': user_stats
        })
    except Exception as e:
        logger.error(f"Error getting user overview: {str(e)}")
        return Response({
            'error': 'Failed to get user overview',
            'detail': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_course_analytics(request):
    """
    Course analytics for admin dashboard
    """
    if not (request.user.is_staff or request.user.is_superuser):
        return Response({
            'error': 'Access denied. Admin privileges required.'
        }, status=status.HTTP_403_FORBIDDEN)
    
    try:
        course_stats = AdminDashboardService.get_course_stats()
        learning_stats = AdminDashboardService.get_learning_stats()
        
        return Response({
            'success': True,
            'data': {
                'courses': course_stats,
                'learning': learning_stats
            }
        })
    except Exception as e:
        logger.error(f"Error getting course analytics: {str(e)}")
        return Response({
            'error': 'Failed to get course analytics',
            'detail': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_revenue_report(request):
    """
    Revenue and subscription analytics
    """
    if not (request.user.is_staff or request.user.is_superuser):
        return Response({
            'error': 'Access denied. Admin privileges required.'
        }, status=status.HTTP_403_FORBIDDEN)
    
    try:
        revenue_stats = AdminDashboardService.get_revenue_stats()
        return Response({
            'success': True,
            'data': revenue_stats
        })
    except Exception as e:
        logger.error(f"Error getting revenue report: {str(e)}")
        return Response({
            'error': 'Failed to get revenue report',
            'detail': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_user_activity(request):
    """
    Real-time user activity monitoring
    """
    if not (request.user.is_staff or request.user.is_superuser):
        return Response({
            'error': 'Access denied. Admin privileges required.'
        }, status=status.HTTP_403_FORBIDDEN)
    
    try:
        # Get query parameters
        time_period = request.query_params.get('period', 'today')  # today, week, month
        limit = int(request.query_params.get('limit', 50))
        
        today = timezone.now().date()
        
        if time_period == 'today':
            start_date = today
        elif time_period == 'week':
            start_date = today - timedelta(days=7)
        elif time_period == 'month':
            start_date = today - timedelta(days=30)
        else:
            start_date = today
        
        # Get active users in the time period
        # Note: We removed DailyActivity model, so this logic needs to be updated.
        # For now, we'll return an empty list or update based on available models like Activity logs if they exist.
        # Since we removed ActivityLog too, we'll return empty data for now.
        
        return Response({
            'success': True,
            'data': {
                'active_users': [],
                'recent_activities': [],
                'time_period': time_period,
                'total_active_users': 0
            }
        })
    except Exception as e:
        logger.error(f"Error getting user activity: {str(e)}")
        return Response({
            'error': 'Failed to get user activity',
            'detail': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET'])
@permission_classes([AllowAny])
def public_social_proof(request):
    """
    Returns the 15 most recent users who have a first name.
    Used for social proof notifications on the landing page.
    """
    try:
        recent_users = User.objects.filter(
            first_name__isnull=False
        ).exclude(
            first_name=''
        ).order_by('-date_joined')[:15]
        
        serializer = PublicSocialProofSerializer(recent_users, many=True)
        return Response(serializer.data)
    except Exception as e:
        logger.error(f"Error fetching social proof: {str(e)}")
        return Response([], status=status.HTTP_200_OK) # Return empty list on error
