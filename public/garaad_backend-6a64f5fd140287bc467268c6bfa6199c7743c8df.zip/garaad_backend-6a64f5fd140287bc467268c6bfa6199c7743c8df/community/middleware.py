from channels.db import database_sync_to_async
from rest_framework_simplejwt.tokens import AccessToken
from django.db import close_old_connections
from urllib.parse import parse_qs
import logging

logger = logging.getLogger(__name__)

@database_sync_to_async
def get_user(user_id):
    from django.contrib.auth import get_user_model
    from django.contrib.auth.models import AnonymousUser
    User = get_user_model()
    try:
        return User.objects.get(id=user_id)
    except User.DoesNotExist:
        return AnonymousUser()

class JwtAuthMiddleware:
    def __init__(self, inner):
        self.inner = inner

    async def __call__(self, scope, receive, send):
        from django.contrib.auth.models import AnonymousUser
        
        # Close old database connections to prevent usage of timed out connections
        close_old_connections()

        # Get the token from query string
        query_string = scope.get("query_string", b"").decode("utf-8")
        query_params = parse_qs(query_string)
        token = query_params.get("token", [None])[0]

        if token:
            try:
                # Validate the token
                access_token = AccessToken(token)
                user_id = access_token["user_id"]
                user = await get_user(user_id)
                scope["user"] = user
                if user.is_authenticated:
                    logger.info(f"WebSocketAuthenticated: User {user.id} ({user.email}) connected")
                else:
                    logger.warning(f"WebSocketAuthFailed: User ID {user_id} not found")
            except Exception as e:
                # Token is invalid
                logger.warning(f"WebSocketTokenInvalid: {str(e)}")
                scope["user"] = AnonymousUser()
        else:
            logger.debug("WebSocketNoToken: Anonymous connection")
            scope["user"] = AnonymousUser()

        return await self.inner(scope, receive, send)

def JwtAuthMiddlewareStack(inner):
    return JwtAuthMiddleware(inner)
