"""
Django signals for automatic notification creation.

This module handles automatic notification generation when:
- A new post is created
- A new reply is created
- A reaction is added (optional based on preferences)
"""

from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from .models import Post, Reply, Reaction, Notification
from .utils import broadcast_community_event
from .serializers import NotificationSerializer
import logging

User = get_user_model()
logger = logging.getLogger(__name__)


@receiver(post_save, sender=Post)
def create_post_notification(sender, instance, created, **kwargs):
    """
    Create notifications when a new post is created.
    
    Notifies users who have pinned the category or are active in it.
    """
    if not created:
        return
    
    try:
        # Get all users to notify (excluding the author)
        all_users = User.objects.exclude(id=instance.author.id)
        
        # Create notifications for each user
        for user in all_users:
            notification = Notification.objects.create(
                recipient=user,
                sender=instance.author,
                type='NEW_POST',
                post=instance,
                is_read=False
            )
            
            # Send push notifications to users with subscriptions
            from .push_utils import send_notification_to_user
            try:
                # Send push notification
                send_notification_to_user(notification.recipient, notification)
                
                # Also broadcast via WebSocket for real-time UI update
                notification_data = NotificationSerializer(notification).data
                broadcast_community_event(
                    room_name=f"user_{notification.recipient.id}",
                    event_type="notification_created",
                    data={"notification": notification_data}
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {user.id}: {str(e)}")
        
        logger.info(f"Created {all_users.count()} notifications for new post {instance.id}")
            
    except Exception as e:
        logger.error(f"Error creating post notifications: {str(e)}")


@receiver(post_save, sender=Reply)
def create_reply_notification(sender, instance, created, **kwargs):
    """
    Create notification when a new reply is created.
    
    Notifies the post author (unless they're replying to their own post).
    """
    if not created:
        return
    
    try:
        post = instance.post
        # Get all users to notify (excluding the reply author)
        all_users = User.objects.exclude(id=instance.author.id)
        
        # Create notifications for each user
        for user in all_users:
            notification = Notification.objects.create(
                recipient=user,
                sender=instance.author,
                type='NEW_REPLY',
                post=post,
                reply=instance,
                is_read=False
            )
            
            # Send push notification to user
            from .push_utils import send_notification_to_user
            try:
                send_notification_to_user(user, notification)
                
                # Also broadcast via WebSocket for real-time UI update
                notification_data = NotificationSerializer(notification).data
                broadcast_community_event(
                    room_name=f"user_{user.id}",
                    event_type="notification_created",
                    data={"notification": notification_data}
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {user.id}: {str(e)}")
        
        logger.info(f"Created {all_users.count()} notifications for reply {instance.id} on post {post.id}")
        
    except Exception as e:
        logger.error(f"Error creating reply notification: {str(e)}")


@receiver(post_save, sender=Reaction)
def create_reaction_notification(sender, instance, created, **kwargs):
    """
    Create notification when a reaction is added to a post.
    
    Notifies the post author (unless they're reacting to their own post).
    This can be toggled via user preferences in the future.
    """
    if not created:
        return
    
    try:
        post = instance.post
        post_author = post.author
        
        # Don't notify if user is reacting to their own post
        if instance.user.id == post_author.id:
            return
        
        # Create notification for post author
        notification = Notification.objects.create(
            recipient=post_author,
            sender=instance.user,
            type='NEW_REACTION',
            post=post,
            is_read=False
        )
        
        logger.info(f"Created notification for reaction {instance.id} on post {post.id}")
        
        # Send push notification to post author
        from .push_utils import send_notification_to_user
        try:
            send_notification_to_user(post_author, notification)
            
            # Also broadcast via WebSocket for real-time UI update
            notification_data = NotificationSerializer(notification).data
            broadcast_community_event(
                room_name=f"user_{post_author.id}",
                event_type="notification_created",
                data={"notification": notification_data}
            )
        except Exception as e:
            logger.error(f"Error sending notification: {str(e)}")
        
    except Exception as e:
        logger.error(f"Error creating reaction notification: {str(e)}")


@receiver(pre_delete, sender=Post)
def delete_post_notifications(sender, instance, **kwargs):
    """
    Delete all notifications related to a post when the post is deleted.
    This prevents orphaned notifications from appearing in the UI.
    """
    try:
        # Delete all notifications for this post
        deleted_count = Notification.objects.filter(post=instance).delete()[0]
        logger.info(f"Deleted {deleted_count} notifications for post {instance.id}")
    except Exception as e:
        logger.error(f"Error deleting post notifications: {str(e)}")


@receiver(pre_delete, sender=Reply)
def delete_reply_notifications(sender, instance, **kwargs):
    """
    Delete all notifications related to a reply when the reply is deleted.
    This prevents orphaned notifications from appearing in the UI.
    """
    try:
        # Delete all notifications for this reply
        deleted_count = Notification.objects.filter(reply=instance).delete()[0]
        logger.info(f"Deleted {deleted_count} notifications for reply {instance.id}")
    except Exception as e:
        logger.error(f"Error deleting reply notifications: {str(e)}")
