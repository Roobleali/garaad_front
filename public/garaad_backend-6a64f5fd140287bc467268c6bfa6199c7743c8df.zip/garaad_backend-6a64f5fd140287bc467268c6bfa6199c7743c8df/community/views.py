from rest_framework import viewsets, permissions, status, filters
from rest_framework.permissions import AllowAny
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db import models
from django.utils import timezone
from .models import Post, PostImage, Reply, Reaction, Notification, PushSubscription
from .serializers import (
    PostSerializer, PostCreateSerializer, ReplySerializer, 
    ReplyCreateSerializer, ReactionSerializer, NotificationSerializer,
    PushSubscriptionSerializer, UserBasicSerializer, CommunityCategorySerializer
)
from .utils import broadcast_community_event
from courses.models import Category
from django.contrib.auth import get_user_model
import logging
import traceback

User = get_user_model()

logger = logging.getLogger(__name__)

class PostViewSet(viewsets.ModelViewSet):
    """
    ViewSet for viewing and creating posts.
    """
    queryset = Post.objects.all().select_related('author', 'category').prefetch_related('replies', 'images', 'reactions')
    serializer_class = PostSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    filter_backends = [filters.OrderingFilter, filters.SearchFilter]
    search_fields = ['content']
    ordering_fields = ['created_at']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'create':
            return PostCreateSerializer
        return PostSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Check for category in path parameters (from URL regex) or query params
        category_id = self.kwargs.get('category_id') or self.request.query_params.get('category')
        
        if category_id:
            queryset = queryset.filter(category_id=category_id)
        
        author_id = self.request.query_params.get('author')
        if author_id:
            queryset = queryset.filter(author_id=author_id)
            
        return queryset

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        
        # Return the full post representation instead of just the create data
        post = serializer.instance
        headers = self.get_success_headers(serializer.data)
        return Response(
            PostSerializer(post, context={'request': request}).data,
            status=status.HTTP_201_CREATED,
            headers=headers
        )

    def perform_create(self, serializer):
        post = serializer.save()
        
        # Broadcast the new post event
        request_id = self.request.data.get('requestId') or self.request.data.get('request_id')
        broadcast_community_event(
            room_name=str(post.category.id),
            event_type='post_created',
            data=PostSerializer(post, context={'request': self.request}).data,
            request_id=request_id
        )

    @action(detail=True, methods=['post'])
    def react(self, request, pk=None):
        """Toggle a reaction on a post"""
        post = self.get_object()
        serializer = ReactionSerializer(
            data=request.data,
            context={'request': request, 'post': post}
        )
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
        try:
            result = serializer.save()
            
            # Broadcast the reaction update
            counts_list = post.reactions.values('type').annotate(count=models.Count('id'))
            reactions_dict = {item['type']: item['count'] for item in counts_list}
            
            request_id = request.data.get('requestId') or request.data.get('request_id')
            broadcast_community_event(
                room_name=str(post.category.id),
                event_type='reaction_updated',
                data={
                    'post_id': str(post.id),
                    'reactions_count': reactions_dict,
                },
                request_id=request_id
            )
            
            return Response(result, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error(f"Reaction error: {str(e)}")
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['get'], permission_classes=[AllowAny])
    def public(self, request):
        """Fetch all public posts for unauthenticated users"""
        queryset = Post.objects.filter(is_public=True).select_related('author', 'category').prefetch_related('replies', 'images', 'reactions')
        
        # Apply ordering
        queryset = queryset.order_by('-created_at')
        
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def perform_destroy(self, instance):
        post_id = str(instance.id)
        category_id = str(instance.category.id)
        request_id = self.request.query_params.get('request_id') or self.request.data.get('request_id')
        
        instance.delete()
        
        # Broadcast the deletion
        broadcast_community_event(
            room_name=category_id,
            event_type='post_deleted',
            data={'post_id': post_id},
            request_id=request_id
        )

class ReplyViewSet(viewsets.ModelViewSet):
    """
    ViewSet for viewing and creating replies.
    """
    queryset = Reply.objects.all().select_related('author', 'post')
    serializer_class = ReplySerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_serializer_class(self):
        if self.action == 'create':
            return ReplyCreateSerializer
        return ReplySerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        post_id = self.request.query_params.get('post')
        if post_id:
            queryset = queryset.filter(post_id=post_id)
        return queryset

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        
        # Return full reply representation
        reply = serializer.instance
        headers = self.get_success_headers(serializer.data)
        return Response(
            ReplySerializer(reply, context={'request': request}).data,
            status=status.HTTP_201_CREATED,
            headers=headers
        )

    def perform_create(self, serializer):
        post_id = self.request.data.get('postId') or self.request.query_params.get('post')
        post = get_object_or_404(Post, id=post_id)
        reply = serializer.save(post=post, author=self.request.user)
        
        # Broadcast the new reply event
        request_id = self.request.data.get('requestId') or self.request.data.get('request_id')
        broadcast_community_event(
            room_name=str(post.category.id),
            event_type='reply_created',
            data={
                'postId': str(post.id),
                'reply': ReplySerializer(reply, context={'request': self.request}).data,
                'replies_count': post.replies.count()
            },
            request_id=request_id
        )

    @action(detail=True, methods=['post'])
    def react(self, request, pk=None):
        """Toggle a reaction on a reply"""
        reply = self.get_object()
        serializer = ReactionSerializer(
            data=request.data,
            context={'request': request, 'reply': reply}
        )
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
        try:
            result = serializer.save()
            
            # Broadcast the reaction update
            counts_list = reply.reactions.values('type').annotate(count=models.Count('id'))
            reactions_dict = {item['type']: item['count'] for item in counts_list}
            
            request_id = request.data.get('requestId') or request.data.get('request_id')
            broadcast_community_event(
                room_name=str(reply.post.category.id),
                event_type='reply_reaction_updated',
                data={
                    'post_id': str(reply.post.id),
                    'reply_id': str(reply.id),
                    'reactions_count': reactions_dict,
                },
                request_id=request_id
            )
            
            return Response(result, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error(f"Reaction error: {str(e)}")
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def perform_destroy(self, instance):
        post = instance.post
        reply_id = str(instance.id)
        post_id = str(post.id)
        category_id = str(post.category.id)
        request_id = self.request.query_params.get('request_id') or self.request.data.get('request_id')
        
        instance.delete()
        
        # Broadcast the deletion
        broadcast_community_event(
            room_name=category_id,
            event_type='reply_deleted',
            data={
                'postId': post_id,
                'reply_id': reply_id,
                'replies_count': post.replies.count()
            },
            request_id=request_id
        )

class CommunityCategoryViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for viewing categories with community features.
    """
    queryset = Category.objects.filter(is_community_enabled=True)
    serializer_class = CommunityCategorySerializer

class UserProfileViewSet(viewsets.ViewSet):
    """
    ViewSet for managing user community profile and preferences.
    """
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=False, methods=['get', 'patch'])
    def me(self, request):
        user = request.user
        if request.method == 'PATCH':
            serializer = UserBasicSerializer(user, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        serializer = UserBasicSerializer(user)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def notification_enabled(self, request):
        """
        Get list of users who have notifications enabled.
        This is used by the frontend to show notification preferences.
        """
        # For now, return all active users
        # In the future, this can be filtered by user preferences
        users = User.objects.filter(is_active=True).exclude(id=request.user.id)
        serializer = UserBasicSerializer(users, many=True)
        return Response(serializer.data)


class NotificationViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing community notifications.
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = NotificationSerializer

    def get_queryset(self):
        return Notification.objects.filter(recipient=self.request.user)

    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        self.get_queryset().update(is_read=True)
        return Response({'status': 'succeeded'})

class PushSubscriptionViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing Web Push subscriptions.
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = PushSubscriptionSerializer

    def get_queryset(self):
        return PushSubscription.objects.filter(user=self.request.user)
