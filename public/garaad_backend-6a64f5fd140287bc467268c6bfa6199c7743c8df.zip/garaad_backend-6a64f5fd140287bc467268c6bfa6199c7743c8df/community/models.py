import uuid
from django.db import models
from django.contrib.auth import get_user_model
from django.conf import settings

User = get_user_model()


class Post(models.Model):
    """
    Community post within a category.
    Simple, clean, no over-engineering.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    category = models.ForeignKey(
        'courses.Category',
        related_name="community_posts",
        on_delete=models.CASCADE
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='community_posts'
    )
    content = models.TextField()
    video_url = models.URLField(max_length=500, blank=True, null=True)
    is_public = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_edited = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['category', '-created_at']),
            models.Index(fields=['author', '-created_at']),
        ]

    def __str__(self):
        return f"{self.author.username}: {self.content[:50]}..."


class PostImage(models.Model):
    """
    Optional image attachments for posts.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    post = models.ForeignKey(
        Post,
        related_name="images",
        on_delete=models.CASCADE
    )
    image = models.ImageField(upload_to="community/posts/")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image for post {self.post.id}"


class Reply(models.Model):
    """
    One-level replies to posts.
    No nested threading - keeps it simple.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    post = models.ForeignKey(
        Post,
        related_name="replies",
        on_delete=models.CASCADE
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='community_replies'
    )
    content = models.TextField()
    video_url = models.URLField(max_length=500, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_edited = models.BooleanField(default=False)

    class Meta:
        ordering = ['created_at']
        verbose_name_plural = "Replies"
        indexes = [
            models.Index(fields=['post', 'created_at']),
        ]

    def __str__(self):
        return f"{self.author.username} replied: {self.content[:50]}..."


class Reaction(models.Model):
    """
    Controlled reactions to posts.
    No karma, no noise - just clean engagement.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    REACTION_CHOICES = [
        ("like", "Like"),
        ("love", "Love"),
        ("haha", "Haha"),
        ("wow", "Wow"),
        ("sad", "Sad"),
        ("angry", "Angry"),
        ("fire", "Fire"),
        ("insight", "Insight"),
    ]

    post = models.ForeignKey(
        Post,
        related_name="reactions",
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    reply = models.ForeignKey(
        Reply,
        related_name="reactions",
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='community_reactions'
    )
    type = models.CharField(max_length=20, choices=REACTION_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.CheckConstraint(
                check=(
                    models.Q(post__isnull=False, reply__isnull=True) |
                    models.Q(post__isnull=True, reply__isnull=False)
                ),
                name="reaction_on_post_or_reply"
            ),
            models.UniqueConstraint(
                fields=['user', 'post'],
                condition=models.Q(post__isnull=False),
                name='unique_user_post_reaction'
            ),
            models.UniqueConstraint(
                fields=['user', 'reply'],
                condition=models.Q(reply__isnull=False),
                name='unique_user_reply_reaction'
            )
        ]
        indexes = [
            models.Index(fields=['post', 'user']),
            models.Index(fields=['reply', 'user']),
        ]

    def __str__(self):
        return f"{self.user.username} reacted {self.type} on post {self.post.id}"
class PostAttachment(models.Model):
    """
    Generic file attachments for posts (Word, PDF, PPT, Video, etc.)
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    post = models.ForeignKey(
        Post,
        related_name="attachments",
        on_delete=models.CASCADE
    )
    file = models.FileField(upload_to="community/posts/attachments/")
    file_type = models.CharField(max_length=50, blank=True)  # e.g., 'application/pdf', 'video/mp4'
    name = models.CharField(max_length=255, blank=True)
    size = models.BigIntegerField(null=True, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Attachment for post {self.post.id}: {self.name}"


class ReplyAttachment(models.Model):
    """
    Generic file attachments for replies.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reply = models.ForeignKey(
        Reply,
        related_name="attachments",
        on_delete=models.CASCADE
    )
    file = models.FileField(upload_to="community/replies/attachments/")
    file_type = models.CharField(max_length=50, blank=True)
    name = models.CharField(max_length=255, blank=True)
    size = models.BigIntegerField(null=True, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Attachment for reply {self.reply.id}: {self.name}"


class Notification(models.Model):
    """
    Community notifications for new posts, replies, and reactions.
    """
    NOTIFICATION_TYPES = [
        ('NEW_POST', 'New Post'),
        ('NEW_REPLY', 'New Reply'),
        ('NEW_REACTION', 'New Reaction'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='community_notifications'
    )
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='sent_notifications',
        null=True,
        blank=True
    )
    type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    post = models.ForeignKey(
        Post,
        on_delete=models.SET_NULL,
        related_name='notifications',
        null=True,
        blank=True
    )
    reply = models.ForeignKey(
        Reply,
        on_delete=models.SET_NULL,
        related_name='notifications',
        null=True,
        blank=True
    )
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['recipient', '-created_at']),
            models.Index(fields=['is_read']),
        ]

    def __str__(self):
        return f"Notification for {self.recipient.username}: {self.type}"


class PushSubscription(models.Model):
    """
    Store Web Push subscriptions for PWA push notifications.
    
    Each user can have multiple subscriptions (different devices/browsers).
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='push_subscriptions'
    )
    endpoint = models.URLField(max_length=500, unique=True)
    p256dh_key = models.TextField(help_text="Public key for encryption")
    auth_key = models.TextField(help_text="Authentication secret")
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['endpoint']),
        ]
    
    def __str__(self):
        return f"Push subscription for {self.user.username}"
