"""
Utility functions for sending Web Push notifications.

This module handles sending push notifications to users via the Web Push protocol.
Requires pywebpush library and VAPID keys configured in settings.
"""

from pywebpush import webpush, WebPushException
from django.conf import settings
import json
import logging

logger = logging.getLogger(__name__)


def send_push_notification(subscription, notification_data):
    """
    Send a push notification to a single subscription.
    
    Args:
        subscription: PushSubscription model instance
        notification_data: dict with 'title', 'body', 'url', etc.
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Prepare the subscription info for pywebpush
        subscription_info = {
            "endpoint": subscription.endpoint,
            "keys": {
                "p256dh": subscription.p256dh_key,
                "auth": subscription.auth_key
            }
        }
        
        # Prepare notification payload
        payload = json.dumps(notification_data)
        
        # Get VAPID keys from settings
        vapid_private_key = getattr(settings, 'VAPID_PRIVATE_KEY', None)
        vapid_claims = {
            "sub": f"mailto:{getattr(settings, 'VAPID_ADMIN_EMAIL', 'admin@garaad.org')}"
        }
        
        if not vapid_private_key:
            logger.warning("VAPID_PRIVATE_KEY not configured in settings. Push notifications will not work.")
            return False
        
        # Send the push notification
        webpush(
            subscription_info=subscription_info,
            data=payload,
            vapid_private_key=vapid_private_key,
            vapid_claims=vapid_claims
        )
        
        logger.info(f"Successfully sent push notification to subscription {subscription.id}")
        return True
        
    except WebPushException as e:
        logger.error(f"WebPush error for subscription {subscription.id}: {str(e)}")
        
        # If subscription is no longer valid (410 Gone), delete it
        if e.response and e.response.status_code == 410:
            logger.info(f"Deleting expired subscription {subscription.id}")
            subscription.delete()
        
        return False
    except Exception as e:
        logger.error(f"Error sending push notification to subscription {subscription.id}: {str(e)}")
        return False


def send_notification_to_user(user, notification):
    """
    Send a push notification to all of a user's subscriptions.
    
    Args:
        user: User model instance
        notification: Notification model instance
    
    Returns:
        int: Number of successful sends
    """
    # Get all active subscriptions for this user
    subscriptions = user.push_subscriptions.all()
    
    if not subscriptions.exists():
        logger.debug(f"No push subscriptions found for user {user.id}")
        return 0
    
    # Prepare notification data
    notification_data = {
        'title': get_notification_title(notification),
        'body': get_notification_body(notification),
        'url': get_notification_url(notification),
        'icon': '/icons/icon-192x192.png',
        'badge': '/icons/icon-192x192.png',
        'data': {
            'notification_id': str(notification.id),
            'type': notification.type,
            'post_id': str(notification.post.id) if notification.post else None,
        }
    }
    
    # Send to all subscriptions
    success_count = 0
    for subscription in subscriptions:
        if send_push_notification(subscription, notification_data):
            success_count += 1
    
    logger.info(f"Sent push notification to {success_count}/{subscriptions.count()} subscriptions for user {user.id}")
    return success_count


def get_notification_title(notification):
    """Generate notification title based on type"""
    sender_name = "Anonymous"
    if notification.sender:
        sender_name = notification.sender.first_name or notification.sender.username

    if notification.type == 'NEW_POST':
        return f"Qoraal cusub: {sender_name}"
    elif notification.type == 'NEW_REPLY':
        return f"Jawaab cusub: {sender_name}"
    elif notification.type == 'NEW_REACTION':
        return f"Falcelin cusub: {sender_name}"
    else:
        return "Ogeysiis cusub"


def get_notification_body(notification):
    """Generate notification body based on type"""
    if notification.type == 'NEW_POST' and notification.post:
        # Truncate post content to 100 characters
        content = notification.post.content[:100]
        if len(notification.post.content) > 100:
            content += "..."
        return content
    elif notification.type == 'NEW_REPLY' and notification.reply:
        # Truncate reply content to 100 characters
        content = notification.reply.content[:100]
        if len(notification.reply.content) > 100:
            content += "..."
        return content
    elif notification.type == 'NEW_REACTION' and notification.post:
        return f"Waxaa la faalceliyay qoraalkaaga"
    else:
        return "Waxaa soo kordhay warar cusub!"


def get_notification_url(notification):
    """Generate the URL to navigate to when notification is clicked"""
    if notification.post:
        category_id = notification.post.category.id
        return f"/community?category={category_id}&post={notification.post.id}"
    return "/community"
