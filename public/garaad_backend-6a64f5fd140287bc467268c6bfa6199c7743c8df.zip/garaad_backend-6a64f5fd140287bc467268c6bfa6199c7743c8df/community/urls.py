from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'posts', views.PostViewSet, basename='post')
router.register(r'replies', views.ReplyViewSet, basename='reply')
router.register(r'categories', views.CommunityCategoryViewSet, basename='category')
router.register(r'profiles', views.UserProfileViewSet, basename='profile')
router.register(r'notifications', views.NotificationViewSet, basename='notification')
router.register(r'push-subscriptions', views.PushSubscriptionViewSet, basename='push-subscription')

app_name = 'community'

urlpatterns = [
    # Profile endpoint for frontend (Must be above router)
    path('profiles/me/', views.UserProfileViewSet.as_view({'get': 'me', 'patch': 'me'}), name='profile-me'),
    
    # Notification endpoints (Must be above router)
    path('notifications/mark_all_as_read/', 
         views.NotificationViewSet.as_view({'post': 'mark_all_read'}), 
         name='notification-mark-all-read'),
    
    # Main router URLs
    path('', include(router.urls)),
    
    # Category-specific posts endpoint
    # GET/POST /api/community/categories/{category_id}/posts/
    re_path(
        r'^categories/(?P<category_id>[^/]+)/posts/?$',
        views.PostViewSet.as_view({'get': 'list', 'post': 'create'}),
        name='category-posts'
    ),
]