from rest_framework import serializers
from django.db import models
from django.contrib.auth import get_user_model
from .models import Post, PostImage, Reply, Reaction, Notification, PushSubscription, PostAttachment, ReplyAttachment
from courses.models import Category

import logging
import traceback

User = get_user_model()

logger = logging.getLogger(__name__)


class UserBasicSerializer(serializers.ModelSerializer):
    """Basic user info for community features"""
    notifications_enabled = serializers.SerializerMethodField()
    pinned_categories = serializers.PrimaryKeyRelatedField(many=True, read_only=True)
    
    class Meta:
        model = User
        fields = ['id', 'username', 'profile_picture', 'first_name', 'last_name', 'notifications_enabled', 'pinned_categories']

    def get_notifications_enabled(self, obj):
        try:
            profile = getattr(obj, 'student_profile', None)
            if profile:
                prefs = profile.get_notification_preferences()
                # Only check email_notifications or default to True
                return prefs.get('email_notifications', True)
            return True # Default to true for social visibility if no profile
        except Exception:
            return False


class ReplyAttachmentSerializer(serializers.ModelSerializer):
    """Reply attachment serializer"""
    
    class Meta:
        model = ReplyAttachment
        fields = ['id', 'file', 'file_type', 'name', 'size', 'uploaded_at']
        read_only_fields = ['uploaded_at']


class CommunityCategorySerializer(serializers.ModelSerializer):
    """Serializer for categories with community status counts"""
    posts_count = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = ['id', 'title', 'description', 'image', 'is_community_enabled', 'community_description', 'posts_count']

    def get_posts_count(self, obj):
        return obj.community_posts.count()


class ReplySerializer(serializers.ModelSerializer):
    """Reply serializer - shallow, no nesting"""
    author = UserBasicSerializer(read_only=True)
    attachments = ReplyAttachmentSerializer(many=True, read_only=True)
    reactions_count = serializers.SerializerMethodField()
    user_reactions = serializers.SerializerMethodField()
    
    class Meta:
        model = Reply
        fields = [
            'id',
            'author',
            'content',
            'video_url',
            'attachments',
            'created_at',
            'updated_at',
            'is_edited',
            'reactions_count',
            'user_reactions'
        ]
        read_only_fields = ['created_at', 'updated_at', 'is_edited']

    def get_reactions_count(self, obj):
        counts = obj.reactions.values('type').annotate(count=models.Count('id'))
        return {item['type']: item['count'] for item in counts}

    def get_user_reactions(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return obj.reactions.filter(user=request.user).values_list('type', flat=True)
        return []


class PostImageSerializer(serializers.ModelSerializer):
    """Post image serializer"""
    
    class Meta:
        model = PostImage
        fields = ['id', 'image', 'uploaded_at']
        read_only_fields = ['uploaded_at']


class PostAttachmentSerializer(serializers.ModelSerializer):
    """Post attachment serializer"""
    
    class Meta:
        model = PostAttachment
        fields = ['id', 'file', 'file_type', 'name', 'size', 'uploaded_at']
        read_only_fields = ['uploaded_at']


class PostSerializer(serializers.ModelSerializer):
    """Post serializer with replies and reaction counts"""
    author = UserBasicSerializer(read_only=True)
    replies = ReplySerializer(many=True, read_only=True)
    images = PostImageSerializer(many=True, read_only=True)
    attachments = PostAttachmentSerializer(many=True, read_only=True)
    reactions_count = serializers.SerializerMethodField()
    user_reactions = serializers.SerializerMethodField()
    replies_count = serializers.IntegerField(source='replies.count', read_only=True)
    
    class Meta:
        model = Post
        fields = [
            'id',
            'category',
            'author',
            'content',
            'video_url',
            'created_at',
            'updated_at',
            'is_edited',
            'images',
            'attachments',
            'replies',
            'replies_count',
            'reactions_count',
            'user_reactions',
            'is_public'
        ]
        read_only_fields = ['created_at', 'updated_at', 'is_edited', 'author']
    
    def get_reactions_count(self, obj):
        """Get count of each reaction type"""
        from django.db.models import Count
        reactions = obj.reactions.values('type').annotate(count=Count('type'))
        return {r['type']: r['count'] for r in reactions}
    
    def get_user_reactions(self, obj):
        """Get current user's reactions to this post"""
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return list(obj.reactions.filter(user=request.user).values_list('type', flat=True))
        return []


class PostCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating posts"""
    content = serializers.CharField(required=False, allow_blank=True)
    
    class Meta:
        model = Post
        fields = ['category', 'content', 'video_url', 'is_public']
    
    def validate(self, data):
        """Ensure either content or files are provided"""
        request = self.context.get('request')
        has_content = data.get('content', '').strip()
        has_images = request and request.FILES.getlist('images')
        has_attachments = request and request.FILES.getlist('attachments')
        has_video = data.get('video_url', '').strip()
        
        if not (has_content or has_images or has_attachments or has_video):
            raise serializers.ValidationError(
                "Waa inaad qortaa qoraal ama aad soo gelisaa sawir/fayl."
            )
        
        return data
    
    def validate_category(self, value):
        """Ensure category has community enabled"""
        if not value.is_community_enabled:
            raise serializers.ValidationError(
                "This category does not have community features enabled."
            )
        return value
    
    def create(self, validated_data):
        """Set author from request user and handle image/file uploads"""
        request = self.context.get('request')
        validated_data['author'] = request.user
        
        # Ensure content is never None, default to empty string
        if 'content' not in validated_data or validated_data['content'] is None:
            validated_data['content'] = ''
        
        # Log what we're receiving
        logger.info(f"Creating post with content: '{validated_data.get('content')}'")
        logger.info(f"Images in request.FILES: {len(request.FILES.getlist('images'))}")
        logger.info(f"Attachments in request.FILES: {len(request.FILES.getlist('attachments'))}")
        
        post = super().create(validated_data)
        
        # Handle multiple images from request.FILES
        images = request.FILES.getlist('images')
        if images:
            logger.info(f"Attempting to upload {len(images)} images for post {post.id}")
            for image_file in images:
                try:
                    PostImage.objects.create(post=post, image=image_file)
                    logger.info(f"Successfully uploaded image {image_file.name} for post {post.id}")
                except Exception as e:
                    logger.error(f"Failed to upload image {image_file.name} for post {post.id}: {str(e)}")
                    logger.error(traceback.format_exc())
        
        # Handle multiple attachments from request.FILES
        attachments = request.FILES.getlist('attachments')
        if attachments:
            logger.info(f"Attempting to upload {len(attachments)} attachments for post {post.id}")
            for file in attachments:
                try:
                    # Ensure content_type is not None and not too long
                    content_type = file.content_type or 'application/octet-stream'
                    if len(content_type) > 50:
                        content_type = content_type[:50]
                    
                    PostAttachment.objects.create(
                        post=post, 
                        file=file,
                        name=file.name,
                        size=file.size,
                        file_type=content_type
                    )
                    logger.info(f"Successfully uploaded attachment {file.name} for post {post.id}")
                except Exception as e:
                    logger.error(f"Failed to upload attachment {file.name} for post {post.id}: {str(e)}")
                    logger.error(traceback.format_exc())
            
        return post


class ReplyCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating replies"""
    content = serializers.CharField(required=False, allow_blank=True)
    
    class Meta:
        model = Reply
        fields = ['content', 'video_url']
    
    def validate(self, data):
        """Ensure either content or files are provided"""
        request = self.context.get('request')
        has_content = data.get('content', '').strip()
        has_attachments = request and request.FILES.getlist('attachments')
        has_video = data.get('video_url', '').strip()
        
        if not (has_content or has_attachments or has_video):
            raise serializers.ValidationError(
                "Waa inaad qortaa qoraal ama aad soo gelisaa fayl."
            )
        
        return data
    
    def create(self, validated_data):
        """Set author and post from context, handle attachments"""
        request = self.context.get('request')
        validated_data['author'] = request.user
        validated_data['post'] = self.context['post']
        reply = super().create(validated_data)
        
        # Handle multiple attachments from request.FILES
        attachments = request.FILES.getlist('attachments')
        if attachments:
            for file in attachments:
                try:
                    ReplyAttachment.objects.create(
                        reply=reply,
                        file=file,
                        name=file.name,
                        size=file.size,
                        file_type=file.content_type
                    )
                except Exception as e:
                    logger.error(f"Failed to upload attachment {file.name} for reply {reply.id}: {str(e)}")
        
        return reply


class ReactionSerializer(serializers.Serializer):
    """Serializer for toggling reactions"""
    type = serializers.ChoiceField(choices=Reaction.REACTION_CHOICES)
    
    def create(self, validated_data):
        """Toggle reaction (create or delete), enforcing one reaction per item"""
        user = self.context['request'].user
        post = self.context.get('post')
        reply = self.context.get('reply')
        reaction_type = validated_data['type']
        
        # Determine the target object (post or reply)
        filter_kwargs = {'user': user}
        if post:
            filter_kwargs['post'] = post
        elif reply:
            filter_kwargs['reply'] = reply
        else:
            raise serializers.ValidationError("Post or Reply context required")

        # Find any existing reaction by this user on this item
        existing_reactions = Reaction.objects.filter(**filter_kwargs)
        
        # If user has a reaction of the DIFFERENT type, remove it first
        other_reactions = existing_reactions.exclude(type=reaction_type)
        if other_reactions.exists():
            other_types = list(other_reactions.values_list('type', flat=True))
            other_reactions.delete()
            # Then create the new one
            reaction_data = {**filter_kwargs, 'type': reaction_type}
            Reaction.objects.create(**reaction_data)
            return {'action': 'switched', 'type': reaction_type, 'removed': other_types}
            
        # If user has a reaction of the SAME type, toggle it (delete)
        same_reaction = existing_reactions.filter(type=reaction_type).first()
        if same_reaction:
            same_reaction.delete()
            return {'action': 'removed', 'type': reaction_type}
        
        # Create new reaction
        reaction_data = {**filter_kwargs, 'type': reaction_type}
        Reaction.objects.create(**reaction_data)
        return {'action': 'added', 'type': reaction_type}


class NotificationSerializer(serializers.ModelSerializer):
    """Serializer for community notifications"""
    sender = UserBasicSerializer(read_only=True)
    notification_type_display = serializers.CharField(source='get_type_display', read_only=True)
    post_id = serializers.SerializerMethodField()
    reply_id = serializers.SerializerMethodField()
    notification_type = serializers.SerializerMethodField()
    category_id = serializers.SerializerMethodField()
    title = serializers.SerializerMethodField()
    message = serializers.SerializerMethodField()
    
    class Meta:
        model = Notification
        fields = [
            'sender',
            'type',
            'notification_type',
            'notification_type_display',
            'title',
            'message',
            'post',
            'post_id',
            'category_id',
            'reply',
            'reply_id',
            'is_read',
            'created_at'
        ]
        read_only_fields = ['created_at']

    def get_post_id(self, obj):
        return str(obj.post.id) if obj.post else None

    def get_reply_id(self, obj):
        return str(obj.reply.id) if obj.reply else None

    def get_category_id(self, obj):
        if obj.post and obj.post.category:
            return str(obj.post.category.id)
        return None

    def get_notification_type(self, obj):
        # Map backend types to frontend union types
        mapping = {
            'NEW_POST': 'post_comment',  # Using post_comment as a fallback icon
            'NEW_REPLY': 'post_comment',
            'NEW_REACTION': 'post_like',
        }
        return mapping.get(obj.type, 'mention')

    def get_title(self, obj):
        from .push_utils import get_notification_title
        return get_notification_title(obj)

    def get_message(self, obj):
        from .push_utils import get_notification_body
        return get_notification_body(obj)


class PushSubscriptionSerializer(serializers.ModelSerializer):
    """Serializer for Web Push subscriptions"""
    
    class Meta:
        model = PushSubscription
        fields = [
            'id',
            'endpoint',
            'p256dh_key',
            'auth_key',
            'created_at'
        ]
        read_only_fields = ['created_at']
    
    def create(self, validated_data):
        """Create or update push subscription for the current user"""
        user = self.context['request'].user
        
        # Check if subscription already exists for this endpoint
        endpoint = validated_data['endpoint']
        subscription, created = PushSubscription.objects.update_or_create(
            endpoint=endpoint,
            defaults={
                'user': user,
                'p256dh_key': validated_data['p256dh_key'],
                'auth_key': validated_data['auth_key'],
            }
        )
        
        return subscription