from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
import logging
import json

logger = logging.getLogger(__name__)

def broadcast_community_event(room_name, event_type, data, request_id=None):
    """
    Broadcasts a community event to a specific room via WebSockets.
    
    room_name: The name of the room (e.g., 'category_uuid' or 'global')
    event_type: The type of event ('post_created', 'reply_created', 'reaction_updated', etc.)
    data: The payload to be sent to the clients
    request_id: Optional ID to help the sender identify their own message (prevents duplication)
    """
    channel_layer = get_channel_layer()
    if not channel_layer:
        logger.error("Channel layer not found. Skipping broadcast.")
        return

    group_name = f"community_{room_name}"
    
    # Payload format expected by the frontend: { "type": "event_type", ...data }
    message_payload = {
        'type': event_type,
        **data
    }
    
    if request_id:
        message_payload['request_id'] = request_id

    # Ensure the payload is JSON serializable (convert UUIDs, datetimes, etc. to strings)
    try:
        message_payload = json.loads(json.dumps(message_payload, default=str))
    except Exception as e:
        logger.error(f"Failed to serialize message payload: {str(e)}")

    message = {
        **message_payload
    }
    
    try:
        async_to_sync(channel_layer.group_send)(
            group_name,
            message
        )
        logger.info(f"Broadcasted {event_type} to {group_name}. Payload: {json.dumps(message_payload)}")
    except Exception as e:
        logger.error(f"Failed to broadcast community event: {str(e)}")