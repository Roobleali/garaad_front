from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    CategoryViewSet, CourseViewSet, LessonViewSet,
    ProblemViewSet, UserProgressViewSet, CourseEnrollmentViewSet,
    LessonContentBlockViewSet
)

router = DefaultRouter()
router.register(r'categories', CategoryViewSet)
router.register(r'courses', CourseViewSet)
router.register(r'lessons', LessonViewSet)
router.register(r'problems', ProblemViewSet)
router.register(r'user-progress', UserProgressViewSet, basename='user-progress')
router.register(r'enrollments', CourseEnrollmentViewSet, basename='enrollment')
router.register(r'lesson-content-blocks', LessonContentBlockViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
