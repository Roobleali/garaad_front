from django.conf import settings
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils import timezone
from datetime import timedelta
from .models import (
    UserProgress, CourseEnrollment, Lesson
)
from django.db import transaction
from django.db.models import F, Sum, OuterRef, Subquery
from django.core.cache import cache
import logging
from accounts.utils import send_resend_email, TEST_MODE

logger = logging.getLogger(__name__)

def get_user_learning_context(user):
    """
    Gathers the user's current learning context for personalized emails.
    """
    enrollment = CourseEnrollment.objects.filter(user=user).order_by('-enrolled_at').first()
    if not enrollment:
        return None

    course = enrollment.course
    progress_percent = enrollment.progress_percent

    # Find the last completed lesson to determine the next one
    last_progress = UserProgress.objects.filter(
        user=user, 
        lesson__course=course, 
        status='completed'
    ).order_by('-lesson__lesson_number').first()

    if last_progress:
        # The next lesson is the one after the last completed lesson
        next_lesson = Lesson.objects.filter(
            course=course,
            lesson_number__gt=last_progress.lesson.lesson_number
        ).order_by('lesson_number').first()
    else:
        # If no lesson is completed, the first lesson is the next one
        next_lesson = Lesson.objects.filter(course=course).order_by('lesson_number').first()

    return {
        "course_name": course.title,
        "progress_percent": progress_percent,
        "next_lesson_title": next_lesson.title if next_lesson else "No more lessons",
        "next_lesson_url": f"/courses/{course.slug}/{next_lesson.slug}/" if next_lesson else f"/courses/{course.slug}/",
        "course_thumbnail": course.thumbnail if course.thumbnail else None
    }

class NotificationService:
    @staticmethod
    def check_and_send_real_time_reminders(user):
        """
        Checks for various real-time events and sends the highest priority notification.
        """
        # --- 1. Check for Inactivity ---
        inactive_days = NotificationService.get_inactivity_days(user)
        if inactive_days and inactive_days >= 1:
            print(f"Condition met: User {user.id} inactive for {inactive_days} days.")
            NotificationService.send_inactivity_reminder(user)
            return

        # --- 2. Check for Daily Reminder ---
        # Check if user hasn't been active today
        if not NotificationService.is_user_active_today(user):
            print(f"Condition met: User {user.id} not active today.")
            NotificationService.send_daily_reminder_notification(user)
            return

    @staticmethod
    def is_user_active_today(user):
        """
        Check if user has been active today using last_active field
        """
        if not user.last_active:
            return False
        
        today = timezone.now().date()
        last_active_date = user.last_active.date()
        
        return last_active_date == today

    @staticmethod
    def get_inactivity_days(user):
        """
        Calculates the number of days a user has been inactive using last_active field.
        """
        if user.last_active:
            return (timezone.now().date() - user.last_active.date()).days
        return None

    @staticmethod
    def send_inactivity_reminder(user):
        """
        Sends a motivational reminder to an inactive user.
        """
        context = get_user_learning_context(user)
        if not context:
            print(f"Could not send inactivity reminder to user {user.id}: No learning context found.")
            return

        try:
            # We will use the general reminder template instead of streak-themed one
            html = render_to_string('emails/daily_reminder.html', context)
            success = send_resend_email(
                to_email=user.email,
                subject='Waxbarashada waa ku sugayaa! Sii wad casharkaaga.',
                html=html
            )
            if success:
                print(f"Successfully sent inactivity reminder to user {user.id}.")
            else:
                print(f"Failed to send inactivity reminder to user {user.id}.")
        except Exception as e:
            print(f"Failed to send inactivity reminder to user {user.id}: {e}")

    @staticmethod
    def send_daily_reminder_notification(user):
        """
        Send a daily reminder notification to encourage learning.
        """
        try:
            context = get_user_learning_context(user)
            if not context:
                context = {
                    'user': user,
                    'site_url': 'https://garaad.org'
                }
            
            # Add daily motivation context
            context['daily_motivation'] = True
            
            html = render_to_string('emails/daily_reminder.html', context)
            success = send_resend_email(
                to_email=user.email,
                subject='Maanta waa maalin wanaagsan oo aad ku baran karto!',
                html=html
            )
            if success:
                print(f"Sent daily reminder to user {user.id}")
                return True
            else:
                print(f"Failed to send daily reminder to user {user.id}")
                return False
                
        except Exception as e:
            print(f"Error sending daily reminder: {e}")
            return False