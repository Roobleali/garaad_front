from django.db import models
from django.utils.text import slugify
from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils import timezone


class Category(models.Model):
    """
    Represents a category of courses.
    """
    id = models.CharField(max_length=50, primary_key=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.CharField(max_length=255)
    in_progress = models.BooleanField(default=False)
    course_ids = models.JSONField(default=list, null=True, blank=True)
    sequence = models.PositiveIntegerField(default=0, help_text="Order in which categories are displayed")
    
    # Community features (additive only)
    is_community_enabled = models.BooleanField(default=True, help_text="Enable community posts for this category")
    community_description = models.TextField(blank=True, help_text="Description for community section")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = "categories"
        ordering = ['sequence', 'title']


class Course(models.Model):
    """
    Represents a course within a category.
    """
    category = models.ForeignKey(
        Category, on_delete=models.CASCADE, related_name="courses")
    title = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True, blank=True)
    is_new = models.BooleanField(default=False)
    progress = models.IntegerField(default=0)
    description = models.TextField()
    thumbnail = models.URLField(blank=True, null=True)
    author_id = models.CharField(max_length=255)
    is_published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-created_at']


class Lesson(models.Model):
    """
    Represents a lesson within a course. Basic lesson info.
    """
    course = models.ForeignKey(
        Course, related_name='lessons', on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255)
    lesson_number = models.PositiveIntegerField(default=1)
    estimated_time = models.PositiveIntegerField(
        help_text="Estimated time in minutes", default=10)
    is_published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.course.title} - {self.title}"

    class Meta:
        ordering = ['course', 'lesson_number']

    def get_next_lesson(self):
        """Returns the next lesson in the course or None if this is the last lesson"""
        try:
            return Lesson.objects.filter(
                course=self.course,
                lesson_number__gt=self.lesson_number
            ).order_by('lesson_number').first()
        except Lesson.DoesNotExist:
            return None


class LessonContentBlock(models.Model):
    """
    A lesson is composed of multiple ordered content blocks.
    Each block can be text, code, image, etc., or can reference a problem.
    This is the central model for organizing lesson content.
    """
    BLOCK_TYPES = [
        ('text', 'Text Block'),
        ('example', 'Example Block'),
        ('code', 'Code Block'),
        ('image', 'Image Block'),
        ('video', 'Video Block'),
        ('quiz', 'Quiz Block'),
        ('problem', 'Problem Block'),  # References Problem model
    ]

    lesson = models.ForeignKey(
        Lesson, related_name='content_blocks', on_delete=models.CASCADE)
    block_type = models.CharField(max_length=20, choices=BLOCK_TYPES)
    order = models.PositiveIntegerField(default=0)
    content = models.JSONField(default=dict, blank=True, null=True)
    problem = models.ForeignKey(
        'Problem', 
        null=True, 
        blank=True, 
        on_delete=models.SET_NULL, 
        help_text="Reference to a Problem for problem-type blocks"
    )

    class Meta:
        ordering = ['lesson', 'order']
        verbose_name = "Lesson Content Block"
        verbose_name_plural = "Lesson Content Blocks"

    # Default content for different block types
    default_content = {
        'text': {
            'text': '',
            'format': 'markdown'
        },
        'example': {
            'title': '',
            'description': '',
            'code': '',
            'language': 'python',
            'explanation': None
        },
        'code': {
            'code': '',
            'language': 'python',
            'explanation': None
        },
        'image': {
            'url': '',
            'caption': None,
            'width': None,
            'height': None,
            'alt_text': None
        },
        'video': {
            'url': '',
            'title': '',
            'description': None,
            'duration': None
        },
        'quiz': {
            'question': '',
            'options': [],
            'correct_answer': 0,
            'explanation': None
        },
        'problem': {
            'introduction': '',
            'show_hints': True,
            'show_solution': False,
            'attempts_allowed': 3,
            'points': 10
        }
    }

    # Content validators for each block type
    type_validators = {
        'text': {
            'text': str,
            'format': str
        },
        'example': {
            'title': str,
            'description': str,
            'code': str,
            'language': str,
            'explanation': (str, type(None))
        },
        'code': {
            'code': str,
            'language': str,
            'explanation': (str, type(None))
        },
        'image': {
            'url': str,
            'caption': (str, type(None)),
            'width': (int, type(None)),
            'height': (int, type(None)),
            'alt_text': (str, type(None))
        },
        'video': {
            'url': str,
            'title': str,
            'description': (str, type(None)),
            'duration': (int, type(None))
        },
        'quiz': {
            'question': str,
            'options': list,
            'correct_answer': int,
            'explanation': (str, type(None))
        },
        'problem': {
            'introduction': str,
            'show_hints': bool,
            'show_solution': bool,
            'attempts_allowed': int,
            'points': int
        }
    }

    @property
    def default_problem_content(self):
        """Default content structure for problem blocks"""
        return {
            "introduction": "",  # Optional text to show before the problem
            "show_hints": True,  # Whether to show hints button
            "show_solution": False,  # Whether to show solution button
            "attempts_allowed": 3,  # Number of attempts allowed
            "points": 10  # Points awarded for correct solution
        }

    def get_complete_content(self):
        """
        Get the complete content for this block, including problem data if it's a problem block
        """
        if self.block_type == 'problem' and self.problem:
            return {
                # Include the display settings from content
                "introduction": self.content.get('introduction', ''),
                "show_hints": self.content.get('show_hints', True),
                "show_solution": self.content.get('show_solution', False),
                "attempts_allowed": self.content.get('attempts_allowed', 3),
                "points": self.content.get('points', 10),
                # Include the actual problem data
                "problem_data": {
                    "id": self.problem.id,
                    "question_text": self.problem.question_text,
                    "question_type": self.problem.question_type,
                    "options": self.problem.options,
                    "content": self.problem.content,
                    "diagram_config": self.problem.diagram_config if self.problem.question_type == 'diagram' else None
                }
            }
        return self.content

    def clean(self):
        """Validate the model before saving"""
        super().clean()
        
        # Ensure content is a dictionary
        if not isinstance(self.content, dict):
            raise ValidationError({
                'content': 'Content must be a dictionary'
            })
            
        # Initialize content if empty
        if not self.content:
            self.content = {}
            
        # Validate content structure
        self.validate_content()
        
        return self.content

    def validate_content(self):
        """Validate content structure based on block_type"""
        if not isinstance(self.content, dict):
            raise ValidationError({
                'content': 'Content must be a dictionary'
            })

        # Skip validation for problem blocks
        if self.block_type == 'problem':
            return

        # Get validators for this block type
        validators = self.type_validators.get(self.block_type)
        if not validators:
            return  # No specific validation for this block type

        # Merge with default content
        default_content = self.default_content.get(self.block_type, {})
        for key, value in default_content.items():
            if key not in self.content:
                self.content[key] = value

        # Validate types for each field
        for field, expected_type in validators.items():
            if field not in self.content:
                raise ValidationError({
                    'content': f'Missing required field: {field}'
                })

            value = self.content[field]
            
            # Handle fields that can accept multiple types
            if isinstance(expected_type, tuple):
                if not any(isinstance(value, t) for t in expected_type if t is not type(None) or value is None):
                    type_names = ' or '.join(t.__name__ for t in expected_type)
                    raise ValidationError({
                        'content': f'Field {field} must be of type {type_names}'
                    })
            else:
                if not isinstance(value, expected_type):
                    raise ValidationError({
                        'content': f'Field {field} must be of type {expected_type.__name__}'
                    })

    def save(self, *args, **kwargs):
        """
        Override save method to validate content before saving
        """
        if not self.content:
            # Initialize with default content for the block type
            if self.block_type == 'problem':
                self.content = {}
            else:
                self.content = self.default_content.get(self.block_type, {})
        else:
            # Skip validation for problem blocks
            if self.block_type != 'problem':
                # Validate content
                self.validate_content()
                # Merge with default content
                default = self.default_content.get(self.block_type, {})
                self.content = {**default, **self.content}
            
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.lesson.title} - {self.get_block_type_display()} Block #{self.order}"


class Problem(models.Model):
    """
    Reusable question entity (used in lessons or practice sets).
    """
    QUESTION_TYPES = (
        ('multiple_choice', 'Multiple Choice'),
        ('single_choice', 'Single Choice'),
        ('true_false', 'True/False'),
        ('fill_blank', 'Fill in the Blank'),
        ('matching', 'Matching'),
        ('open_ended', 'Open Ended'),
        ('math_expression', 'Math Expression'),
        ('code', 'Coding Problem'),
        ('diagram', 'Diagram Problem'),
    )

    lesson = models.ForeignKey(
        Lesson, related_name='problems', on_delete=models.CASCADE, null=True, blank=True)
    which = models.TextField(blank=True, null=True, help_text="Additional text field before question")
    question_text = models.TextField()
    question_type = models.CharField(max_length=20, choices=QUESTION_TYPES)
    options = models.JSONField(
        null=True, blank=True, help_text="Answer options for applicable question types")
    correct_answer = models.JSONField(
        help_text="Correct answer(s) in format appropriate for question_type")
    explanation = models.TextField(
        blank=True, help_text="Explanation of the answer")
    order = models.PositiveIntegerField(default=0)
    content = models.JSONField(default=dict, blank=True, null=True)
    diagram_config = models.JSONField(default=dict, blank=True)
    diagrams = models.JSONField(null=True, blank=True, help_text="Multiple diagram configurations for complex problems")
    img = models.URLField(blank=True, null=True, help_text="URL of an image associated with the problem")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['lesson', 'order']
        unique_together = ['lesson', 'order']

    def clean(self):
        """
        Validate the problem data before saving
        """
        super().clean()
        
        # Initialize empty fields if needed
        if not self.content or self.content == []:
            self.content = {}
        
        # Validate diagram configuration exclusivity
        if self.question_type == 'diagram':
            has_single_diagram = self.diagram_config and self.diagram_config != {}
            has_multiple_diagrams = self.diagrams and self.diagrams != []
            
            if has_single_diagram and has_multiple_diagrams:
                raise ValidationError({
                    'diagram_config': 'Cannot use both diagram_config and diagrams simultaneously'
                })
            
            if not has_single_diagram and not has_multiple_diagrams:
                raise ValidationError({
                    'diagram_config': 'Diagram problems require either diagram_config or diagrams'
                })
            
            # Validate single diagram structure
            if has_single_diagram:
                self.validate_single_diagram(self.diagram_config)
            
            # Validate multiple diagrams structure
            if has_multiple_diagrams:
                self.validate_multiple_diagrams(self.diagrams)
        
        # Validate multiple choice questions
        if self.question_type in ['multiple_choice', 'single_choice']:
            # Initialize options and correct_answer if empty
            if not self.options:
                self.options = []
            if not self.correct_answer:
                self.correct_answer = []
            
            # Validate options
            if not self.options:
                raise ValidationError({
                    'options': 'Options are required for multiple choice questions'
                })
            
            # Validate each option
            for option in self.options:
                if not isinstance(option, dict):
                    raise ValidationError({
                        'options': 'Each option must be a dictionary'
                    })
                if 'id' not in option or 'text' not in option:
                    raise ValidationError({
                        'options': 'Each option must have an id and text field'
                    })
            
            # Validate correct_answer
            if not self.correct_answer:
                raise ValidationError({
                    'correct_answer': 'Correct answer is required for multiple choice questions'
                })
            
            # For single choice, ensure only one correct answer
            if self.question_type == 'single_choice' and len(self.correct_answer) > 1:
                raise ValidationError({
                    'correct_answer': 'Single choice questions can only have one correct answer'
                })
            
            # Validate correct_answer IDs exist in options
            option_ids = {opt.get('id') for opt in self.options}
            for answer in self.correct_answer:
                if not isinstance(answer, dict):
                    raise ValidationError({
                        'correct_answer': 'Each answer must be a dictionary'
                    })
                if 'id' not in answer:
                    raise ValidationError({
                        'correct_answer': 'Each answer must have an id field'
                    })
                if answer.get('id') not in option_ids:
                    raise ValidationError({
                        'correct_answer': f"Answer ID '{answer.get('id')}' not found in options"
                    })

    def validate_single_diagram(self, diagram_config):
        """Validate single diagram configuration structure"""
        required_fields = ['diagram_id', 'diagram_type', 'scale_weight', 'objects']
        for field in required_fields:
            if field not in diagram_config:
                raise ValidationError({
                    'diagram_config': f'Missing required field: {field}'
                })
        
        # Validate objects
        for obj in diagram_config.get('objects', []):
            self.validate_diagram_object(obj)
    
    def validate_multiple_diagrams(self, diagrams):
        """Validate multiple diagrams configuration structure"""
        if not isinstance(diagrams, list) or len(diagrams) == 0:
            raise ValidationError({
                'diagrams': 'Diagrams must be a non-empty array'
            })
        
        for i, diagram in enumerate(diagrams):
            try:
                self.validate_single_diagram(diagram)
            except ValidationError as e:
                # Re-raise with diagram index for clarity
                raise ValidationError({
                    'diagrams': f'Diagram {i}: {str(e.message_dict)}'
                })
    
    def validate_diagram_object(self, obj):
        """Validate diagram object structure"""
        required_fields = ['type', 'color', 'text_color', 'number', 'position', 'layout']
        for field in required_fields:
            if field not in obj:
                raise ValidationError({
                    'diagram_config': f'Object missing required field: {field}'
                })
        
        # Validate layout
        layout = obj.get('layout', {})
        layout_fields = ['rows', 'columns', 'position', 'alignment']
        for field in layout_fields:
            if field not in layout:
                raise ValidationError({
                    'diagram_config': f'Layout missing required field: {field}'
                })

    def save(self, *args, **kwargs):
        if not self.order and self.lesson:
            # Get the highest order number for this lesson
            last_order = Problem.objects.filter(lesson=self.lesson).aggregate(
                models.Max('order'))['order__max'] or 0
            # Get the highest order number from content blocks
            last_content_order = LessonContentBlock.objects.filter(
                lesson=self.lesson).aggregate(models.Max('order'))['order__max'] or 0
            # Set order to the next available number
            self.order = max(last_order, last_content_order) + 1
        
        # Initialize content if empty or None
        if self.content is None or self.content == []:
            self.content = {}
        
        # Initialize diagram configuration if it's a diagram problem
        if self.question_type == 'diagram':
            # Ensure at least one diagram format is initialized
            if not self.diagram_config and not self.diagrams:
                self.diagram_config = {}
        
        # Run validation
        self.clean()
        
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.question_text[:50]}..."

    class Meta:
        ordering = ['lesson', 'order']
        unique_together = ['lesson', 'order']


class Hint(models.Model):
    """
    Gradual hints for a problem.
    """
    problem = models.ForeignKey(
        Problem, related_name='hints', on_delete=models.CASCADE)
    content = models.TextField()
    order = models.PositiveIntegerField(
        default=0, help_text="Order in which hints are revealed")

    def __str__(self):
        return f"Hint #{self.order} for Problem {self.problem.id}"

    class Meta:
        ordering = ['problem', 'order']
        unique_together = ['problem', 'order']


class SolutionStep(models.Model):
    """
    Step-by-step solution to a problem.
    """
    problem = models.ForeignKey(
        Problem, related_name='solution_steps', on_delete=models.CASCADE)
    explanation = models.TextField()
    order = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"Solution Step #{self.order} for Problem {self.problem.id}"

    class Meta:
        ordering = ['problem', 'order']
        unique_together = ['problem', 'order']


class UserProgress(models.Model):
    """
    Tracks a user's progress on each lesson.
    """
    STATUS_CHOICES = (
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='progress', on_delete=models.CASCADE)
    lesson = models.ForeignKey(
        Lesson, related_name='user_progress', on_delete=models.CASCADE)
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='not_started')
    score = models.PositiveIntegerField(blank=True, null=True)
    last_visited_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(blank=True, null=True)
    problems_solved = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ['user', 'lesson']
        verbose_name = "User Progress"
        verbose_name_plural = "User Progress"

    def __str__(self):
        return f"{self.user.username} - {self.lesson.title} ({self.status})"

    def mark_as_in_progress(self):
        """Mark lesson as in progress if not already completed"""
        if self.status != 'completed':
            self.status = 'in_progress'
            self.save()

    def mark_as_completed(self, score=None):
        """Mark the lesson as completed"""
        self.status = 'completed'
        self.completed_at = timezone.now()
        if score is not None:
            self.score = score
        
        self.save()
        
        # Update course progress
        CourseEnrollment.update_progress(self.user, self.lesson.course)


class CourseEnrollment(models.Model):
    """
    Tracks which course the user is enrolled in and their progress.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='enrollments', on_delete=models.CASCADE)
    course = models.ForeignKey(
        Course, related_name='enrollments', on_delete=models.CASCADE)
    enrolled_at = models.DateTimeField(auto_now_add=True)
    progress_percent = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ['user', 'course']

    def __str__(self):
        return f"{self.user.username} - {self.course.title} ({self.progress_percent}%)"

    @classmethod
    def update_progress(cls, user, course):
        """Update progress percentage based on completed lessons"""
        # Get or create enrollment
        enrollment, created = cls.objects.get_or_create(
            user=user,
            course=course
        )

        # Count total lessons in the course
        total_lessons = Lesson.objects.filter(course=course).count()

        if total_lessons > 0:
            # Count completed lessons
            completed_lessons = UserProgress.objects.filter(
                user=user,
                lesson__course=course,
                status='completed'
            ).count()

            # Calculate percentage
            enrollment.progress_percent = int(
                (completed_lessons / total_lessons) * 100)
            enrollment.save()

        return enrollment

    @classmethod
    def enroll_user(cls, user, course):
        """Enroll a user in a course if not already enrolled"""
        enrollment, created = cls.objects.get_or_create(
            user=user,
            course=course
        )
        return enrollment


class UserProblem(models.Model):
    """
    Tracks a user's progress on individual problems.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        related_name='solved_problems', 
        on_delete=models.CASCADE
    )
    problem = models.ForeignKey(
        Problem, 
        related_name='user_solutions', 
        on_delete=models.CASCADE
    )
    solved = models.BooleanField(default=False)
    solved_at = models.DateTimeField(null=True, blank=True)
    attempts = models.PositiveIntegerField(default=0)
    
    class Meta:
        unique_together = ['user', 'problem']
        ordering = ['-solved_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.problem.question_text[:50]}"
    
    def mark_as_solved(self):
        """Mark problem as solved"""
        if not self.solved:
            self.solved = True
            self.solved_at = timezone.now()
            self.save()
            
            # Update lesson progress
            progress, _ = UserProgress.objects.get_or_create(
                user=self.user,
                lesson=self.problem.lesson,
                defaults={
                    'status': 'in_progress',
                    'problems_solved': 0,
                }
            )
            progress.problems_solved += 1
            progress.save()
            
            return True
        return False
