import os
import django
import sys
import json
from django.test import Client, override_settings
from unittest.mock import patch, MagicMock

# Setup Django environment
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'garaad.settings')
django.setup()

from community.utils import broadcast_community_event
from django.contrib.auth import get_user_model
from courses.models import Category
from community.models import Post

User = get_user_model()

def test_realtime_broadcast():
    print("--- REAL-TIME BROADCAST DIAGNOSTIC ---")
    
    # 1. Test the utility function isolation
    print("\n1. Testing broadcast_community_event utility...")
    with patch('community.utils.get_channel_layer') as mock_get_layer:
        mock_layer = MagicMock()
        mock_get_layer.return_value = mock_layer
        
        broadcast_community_event("test_room", "test_event", {"foo": "bar"})
        
        # Verify group_send was called
        mock_layer.group_send.assert_called_once()
        args, kwargs = mock_layer.group_send.call_args
        print(f"Room: {args[0]}")
        print(f"Payload: {args[1]}")
        
        if args[0] == "community_test_room" and args[1]['message']['type'] == "test_event":
            print("Utility Check: PASSED")
        else:
            print("Utility Check: FAILED")

    # 2. Test Post Creation Broadcast
    print("\n2. Testing Post Creation View Broadcast...")
    client = Client()
    user_email = "test_broadcast@example.com"
    User.objects.filter(email=user_email).delete()
    user = User.objects.create_user(username="broadcaster", email=user_email, password="password123")
    
    cat_id = "test-broadcast-cat"
    Category.objects.filter(id=cat_id).delete()
    category = Category.objects.create(id=cat_id, title="Broadcast Lab", is_community_enabled=True)
    
    client.force_login(user)
    
    with patch('community.views.broadcast_community_event') as mock_broadcast:
        data = {
            "content": "Real-time test post",
            "category": str(category.id)
        }
        response = client.post(f'/api/community/categories/{category.id}/posts/', data=json.dumps(data), content_type='application/json')
        
        if response.status_code == 201:
            mock_broadcast.assert_called()
            call_args = mock_broadcast.call_args[1]
            print(f"Broadcast Room: {call_args['room_name']}")
            print(f"Event Type: {call_args['event_type']}")
            
            if call_args['room_name'] == str(category.id) and call_args['event_type'] == 'post_created':
                print("View Integration Check: PASSED")
            else:
                print("View Integration Check: FAILED")
        else:
            print(f"Post creation failed with status {response.status_code}")
            if response.status_code != 404:
                print(f"Error: {response.content.decode()[:500]}")

    # 3. Test Reaction Broadcast
    print("\n3. Testing Reaction View Broadcast...")
    post = Post.objects.create(author=user, category=category, content="React to me")
    
    with patch('community.views.broadcast_community_event') as mock_broadcast:
        data = {"type": "like"}
        response = client.post(f'/api/community/posts/{post.id}/react/', data=json.dumps(data), content_type='application/json')
        
        if response.status_code == 200:
            mock_broadcast.assert_called_once()
            call_args = mock_broadcast.call_args[1]
            print(f"Broadcast Room: {call_args['room_name']}")
            print(f"Event Type: {call_args['event_type']}")
            print(f"Reactions Data: {call_args['data'].get('reactions_count')}")
            
            if call_args['event_type'] == 'reaction_updated' and 'like' in call_args['data'].get('reactions_count', {}):
                print("Reaction Broadcast Check: PASSED")
            else:
                print("Reaction Broadcast Check: FAILED")
        else:
            print(f"Reaction failed: {response.status_code} {response.content.decode()}")

    # Cleanup
    Post.objects.filter(id=post.id).delete()
    category.delete()
    user.delete()

if __name__ == "__main__":
    test_realtime_broadcast()
