import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'garaad.settings')
django.setup()

from api.admin_dashboard import AdminDashboardService

methods = [
    'get_overview_stats',
    'get_user_stats',
    'get_course_stats',
    'get_learning_stats',
    'get_engagement_stats',
    'get_revenue_stats',
    'get_system_stats',
    'get_recent_activity',
    'get_top_performers',
    'get_system_alerts'
]

for method_name in methods:
    try:
        print(f"Testing {method_name}...")
        method = getattr(AdminDashboardService, method_name)
        data = method()
        print(f"  {method_name} passed.")
    except Exception as e:
        print(f"  {method_name} FAILED: {e}")
        import traceback
        traceback.print_exc()

try:
    print("Testing get_dashboard_data...")
    AdminDashboardService.get_dashboard_data()
    print("  get_dashboard_data passed.")
except Exception as e:
    print(f"  get_dashboard_data FAILED: {e}")
