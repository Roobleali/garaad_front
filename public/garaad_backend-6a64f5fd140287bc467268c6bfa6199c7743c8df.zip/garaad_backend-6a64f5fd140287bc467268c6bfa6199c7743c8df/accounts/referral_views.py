"""
New referral API endpoints for enhanced referral program.
"""
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import get_user_model
from django.db.models import Sum, Q
from decimal import Decimal

User = get_user_model()


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def generate_referral_link_view(request):
    """
    Generate a shareable referral link for the current user.
    Returns the full URL with the user's referral code.
    """
    user = request.user
    
    # Get the frontend URL from settings or use default
    from django.conf import settings
    frontend_url = getattr(settings, 'FRONTEND_URL', 'https://garaad.vercel.app')
    
    # Generate the referral link
    referral_link = f"{frontend_url}/welcome?ref={user.referral_code}"
    
    return Response({
        'referral_code': user.referral_code,
        'referral_link': referral_link,
        'message': 'Casuun saaxiibbadaada oo la baro Garaad!'  # Invite your friends to learn with Garaad!
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def referral_earnings_view(request):
    """
    Get referral earnings data for the current user.
    Returns total earnings, pending rewards, and paid rewards.
    """
    from accounts.models import ReferralReward
    
    user = request.user
    
    # Get all rewards for this user
    all_rewards = ReferralReward.objects.filter(referrer=user)
    
    # Calculate totals by status
    total_earnings = all_rewards.aggregate(
        total=Sum('reward_amount')
    )['total'] or Decimal('0.00')
    
    pending_earnings = all_rewards.filter(status='pending').aggregate(
        total=Sum('reward_amount')
    )['total'] or Decimal('0.00')
    
    paid_earnings = all_rewards.filter(status='paid').aggregate(
        total=Sum('reward_amount')
    )['total'] or Decimal('0.00')
    
    # Get recent rewards
    from accounts.serializers import ReferralRewardSerializer
    recent_rewards = all_rewards.order_by('-created_at')[:10]
    recent_rewards_data = ReferralRewardSerializer(recent_rewards, many=True).data
    
    return Response({
        'total_earnings': str(total_earnings),
        'pending_earnings': str(pending_earnings),
        'paid_earnings': str(paid_earnings),
        'currency': 'USD',  # Default currency
        'total_rewards_count': all_rewards.count(),
        'recent_rewards': recent_rewards_data
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def referral_dashboard_view(request):
    """
    Complete referral dashboard data including stats, earnings, and referred users.
    This is the main endpoint for the referral dashboard page.
    """
    from accounts.models import ReferralReward
    from accounts.serializers import ReferredUserSerializer, ReferralRewardSerializer
    
    user = request.user
    
    # Get referred users
    referred_users = user.get_referral_list()
    referred_users_data = ReferredUserSerializer(referred_users, many=True).data
    
    # Get referral rewards
    all_rewards = ReferralReward.objects.filter(referrer=user)
    
    # Calculate earnings
    total_earnings = all_rewards.aggregate(
        total=Sum('reward_amount')
    )['total'] or Decimal('0.00')
    
    pending_earnings = all_rewards.filter(status='pending').aggregate(
        total=Sum('reward_amount')
    )['total'] or Decimal('0.00')
    
    # Calculate conversion rate
    total_referred = referred_users.count()
    subscribed_count = all_rewards.values('referred_user').distinct().count()
    conversion_rate = (subscribed_count / total_referred * 100) if total_referred > 0 else 0
    
    # Get referral link
    from django.conf import settings
    frontend_url = getattr(settings, 'FRONTEND_URL', 'https://garaad.vercel.app')
    referral_link = f"{frontend_url}/welcome?ref={user.referral_code}"
    
    # Recent rewards
    recent_rewards = all_rewards.order_by('-created_at')[:5]
    recent_rewards_data = ReferralRewardSerializer(recent_rewards, many=True).data
    
    return Response({
        'referral_code': user.referral_code,
        'referral_link': referral_link,
        'referral_points': user.referral_points,
        'total_referred': total_referred,
        'subscribed_count': subscribed_count,
        'conversion_rate': round(conversion_rate, 2),
        'total_earnings': str(total_earnings),
        'pending_earnings': str(pending_earnings),
        'currency': 'USD',
        'referred_users': referred_users_data,
        'recent_rewards': recent_rewards_data,
        'motivational_message': 'Saaxiibbadaa u sheeg Garaad oo hel lacag!'  # Tell your friends about Garaad and earn money!
    }, status=status.HTTP_200_OK)
