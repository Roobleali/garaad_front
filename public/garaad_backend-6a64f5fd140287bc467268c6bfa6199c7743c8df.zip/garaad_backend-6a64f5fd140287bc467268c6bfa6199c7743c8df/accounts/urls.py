from django.urls import path
from . import views
from . import referral_views

urlpatterns = [
    path('signin/', views.custom_login, name='custom_login'),
    path('signup/', views.signup_view, name='signup'),
    path('profile/', views.user_profile, name='user_profile'),
    path('user-profile/', views.get_user_profile, name='get_user_profile'),
    path('update-user-profile/', views.update_user_profile, name='update_user_profile'),
    path('upload-profile-picture/', views.upload_profile_picture, name='upload_profile_picture'),
    path('delete-profile-picture/', views.delete_profile_picture, name='delete_profile_picture'),
    path('update-premium/', views.update_premium_status, name='update_premium_status'),
    path('refresh/', views.CustomTokenRefreshView.as_view(), name='token_refresh'),
    path('verify-email/', views.verify_email, name='verify_email'),
    path('resend-verification/', views.resend_verification_email, name='resend_verification_email'),
    
    # Referral endpoints
    path('referrals/', views.referrals_view, name='referrals'),
    path('referral-list/', views.referrals_view, name='referral_list_alias'),
    path('referral-stats/', views.referral_stats_view, name='referral_stats'),
    path('generate-referral-code/', views.generate_referral_code_view, name='generate_referral_code'),
    
    # New enhanced referral endpoints
    path('referral-link/', referral_views.generate_referral_link_view, name='generate_referral_link'),
    path('referral-earnings/', referral_views.referral_earnings_view, name='referral_earnings'),
    path('referral-dashboard/', referral_views.referral_dashboard_view, name='referral_dashboard'),
]
