export const baseURL = "https://api.garaad.org"; // Update this with your actual API base URL
